
 const  getCookies = function (name="")  {
    const regex = new RegExp(`(^| )${name}=([^;]+)`)
    const match = document.cookie.match(regex)
    if (match) {
      return match[2]
    }
  }
  export function getHeaders({headers={}}){
    const x = localStorage.getItem("token")
    const defaultHeaders = {    
  
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    'Authorization': 'Bearer '+x,
    ...headers
    }
 
    return defaultHeaders;
    
  }





  
  export async function fetchApi(base_url:string, params:any){
    const headers = getHeaders(params);
    const response = await fetch(`${base_url}`, {
        method: "GET",
        ...params,
        headers});
        
        
    return response;  
  } 
  export function processError(error:any){  
    const {statusCode=""} = error;
    clearStorage();  
  } 
 
   export function clearStorage(){  
      localStorage.clear();
      window.location.href = '/';
       //navigate('/principal')
   }
  
   export const enum AppConstants {
    userId = "00000000-0000-0000-0000-000000000000",
    backendAPI = "http://localhost:8000",
     backendAPI_LOC= "https://apim-ka-prod.azure-api.net/tl",
  }