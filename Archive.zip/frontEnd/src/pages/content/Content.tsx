import React, { useState } from "react";
import { Pivot, PivotItem } from "@fluentui/react";
import { ITag } from "@fluentui/react/lib/Pickers";
import { FilePicker } from "../../components/filepicker/file-picker";
 
import { getPromptsData, updatePrompt } from "../../api";
 import styles from "./Content.module.css";
 


export interface IButtonExampleProps {
    disabled?: boolean;
    checked?: boolean;
}

const Content = () => {
    const [selectedKey, setSelectedKey] = useState<string | undefined>(undefined);
    const [selectedTags, setSelectedTags] = useState<string[] | undefined>(undefined);
 

    const onSelectedKeyChanged = (selectedFolder: string[]) => {
        setSelectedKey(selectedFolder[0]);
    };

    const onSelectedTagsChanged = (selectedTags: ITag[]) => {
        setSelectedTags(selectedTags.map(tag => tag.name));
    };

    const handleLinkClick = async (item?: PivotItem) => {
        if (item?.props?.headerText === "Prompts") {
            const data = await getPromptsData();
       
        }
        setSelectedKey(undefined);
    };

    const handleUpdate = async (promptType: string, prompt: string) => {
        try {
            await updatePrompt(promptType, { prompt });
            alert("Prompt updated successfully!");
        } catch (error) {
            console.error("Error updating prompt:", error);
            alert("Failed to update prompt.");
        }
    };

    return (
        <div className={styles.contentArea}>
            <Pivot aria-label="Upload Files Section" className={styles.topPivot} onLinkClick={handleLinkClick}>

            <PivotItem headerText="Upload Files" aria-label="Upload Files Tab">
                    <div className={styles.App}>
                        <h2>Upload your files</h2>
                
                        <FilePicker folderPath={selectedKey || ""} tags={selectedTags || []} />
                    </div>
                </PivotItem>
            </Pivot>
        </div>
    );
};

export default Content;
