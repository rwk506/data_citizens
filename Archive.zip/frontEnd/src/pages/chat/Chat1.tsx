// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.

import { useRef, useState, useEffect, useLayoutEffect } from "react";
import {} from "@fluentui/react";
import { GlobeFilled, BuildingMultipleFilled, AddFilled, ChatSparkleFilled } from "@fluentui/react-icons";
import { ITag } from "@fluentui/react/lib/Pickers";
import {
    Toggle,
    Label,
    Checkbox,
    Panel,
    DefaultButton,
    TextField,
    SpinButton,
    Separator,
    ComboBox,
    IComboBox,
    IComboBoxOption,
    TooltipHost,
    ITooltipHostStyles,
    mergeStyles
} from "@fluentui/react";

import styles from "./Chat.module.css";
import rlbgstyles from "../../components/ResponseLengthButtonGroup/ResponseLengthButtonGroup.module.css";
import rtbgstyles from "../../components/ResponseTempButtonGroup/ResponseTempButtonGroup.module.css";
import Button from "@mui/material/Button";
import { AppConstants } from "../../utilities/utils";
import { Navbar } from 'react-chat-elements';
import {
    chatApiV2,
    Approaches,
    ChatResponse,
    ChatTurn,
    ChatMode,
    ChatRequestV2,
    chatHistoryapi,
    deleteChatThread,
    getRagScores,
    logoutFromApplication
} from "../../api";
import { Answer, AnswerError } from "../../components/Answer";
import { QuestionInput } from "../../components/QuestionInput";
import { ExampleList } from "../../components/Example";
import { UserChatMessage } from "../../components/UserChatMessage";
import { AnalysisPanelV2, AnalysisPanelTabs } from "../../components/AnalysisPanel";
import { SettingsButton } from "../../components/SettingsButton";
import { InfoButton } from "../../components/InfoButton";
import { ClearChatButton } from "../../components/ClearChatButton";
import { ResponseLengthButtonGroup } from "../../components/ResponseLengthButtonGroup";
import { ResponseTempButtonGroup } from "../../components/ResponseTempButtonGroup";
/* import { ChatModeButtonGroup } from "../../components/ChatModeButtonGroup";
 */ import { InfoContent } from "../../components/InfoContent/InfoContent";
import { FolderPicker, FolderPickerNested } from "../../components/FolderPicker";
import { TagPickerInline } from "../../components/TagPicker";
import React from "react";
import { Info16Regular, History24Regular, Document24Regular } from "@fluentui/react-icons";
import CircularProgress from "@mui/material/CircularProgress";
import Backdrop from "@mui/material/Backdrop";

import Accordion from "@mui/material/Accordion";
import AccordionSummary from "@mui/material/AccordionSummary";
import AccordionDetails from "@mui/material/AccordionDetails";
import { NavLink } from "react-router-dom";
import Modal from "@mui/material/Modal";
import Box from "@mui/material/Box";
import { FileDropdown } from "../../components/FileDropdown";
import useMobileScreen from "./useMobileScreen";
import { ChatHistory } from "../../components/ChatHistory/ChatHistory";
import Typography from "@mui/material/Typography";
 
interface User {
    message: string;
    onEditSubmit: (msg: any) => void;
    envConfig: any;
}
interface Props {
    envConfig?: any;
    userDetails?: any;
}

const Chat = ({ envConfig, userDetails = {} }: Props) => {
    const [isConfigPanelOpen, setIsConfigPanelOpen] = useState(false);
    const [isInfoPanelOpen, setIsInfoPanelOpen] = useState(false);
    const [retrieveCount, setRetrieveCount] = useState<number>(envConfig?.document_retriever_count || 5);
    const [useSuggestFollowupQuestions, setUseSuggestFollowupQuestions] = useState<boolean>(true);
    const [userPersona, setUserPersona] = useState<string>("analyst");
    const [systemPersona, setSystemPersona] = useState<string>("an Assistant");
    const [promptTemplate, setPromptTemplate] = useState<string>("");
    const [excludeCategory, setExcludeCategory] = useState<string>("");
    const [useSemanticRanker, setUseSemanticRanker] = useState<boolean>(false);
    const [useEnrichedEmbeddings, setUseEnrichEmbeddings] = useState<boolean>(false);
    const [useMultiVectorQuery, setMultivectorQuery] = useState<boolean>(false);
    const [aiPersona, setAiPersona] = useState<string>("");
    const [useSemanticCaptions, setUseSemanticCaptions] = useState<boolean>(false);

    // Setting responseLength to 2048 by default, this will effect the default display of the ResponseLengthButtonGroup below.
    // It must match a valid value of one of the buttons in the ResponseLengthButtonGroup.tsx file.
    // If you update the default value here, you must also update the default value in the onResponseLengthChange method.
    const [responseLength, setResponseLength] = useState<number>(1024);
    // Setting responseTemp to 0.6 by default, this will effect the default display of the ResponseTempButtonGroup below.
    // It must match a valid value of one of the buttons in the ResponseTempButtonGroup.tsx file.
    // If you update the default value here, you must also update the default value in the onResponseTempChange method.
    const [responseTemp, setResponseTemp] = useState<number>(0.6);

    const [activeChatMode, setChatMode] = useState<ChatMode>(ChatMode.WorkOnly);
    const [defaultApproach, setDefaultApproach] = useState<string>(Approaches.ReadRetrieveRead);
    const [activeApproach, setActiveApproach] = useState<string>(Approaches.ReadRetrieveRead);
    /*     const [featureFlags, setFeatureFlags] = useState<GetFeatureFlagsResponse | undefined>(undefined);
     */
    const lastQuestionRef = useRef<string>("");
    const lastQuestionWorkCitationRef = useRef<{ [key: string]: { citation: string; source_path: string; page_number: string } }>({});
    const lastQuestionWebCitiationRef = useRef<{ [key: string]: { citation: string; source_path: string; page_number: string } }>({});
    const lastQuestionThoughtChainRef = useRef<{ [key: string]: string }>({});
    const chatMessageStreamEnd = useRef<HTMLDivElement | null>(null);
    const [isChatHistoryOpen, setIsChatHistoryPanelOpen] = useState(false);
    const [history, setChatHistory] = useState<any[]>([]);
    const [isChatHistoryLoaded, setChatHistoryLoaded] = useState<boolean>(false);
    const [adjustPanelModal, setAdjustPanelModal] = useState(false);
    const handleCloseAdjustPanelModal = () => setAdjustPanelModal(false);
    const [evalScore, setEvalScore] = useState<any>([]);

    const [activeCitation, setActiveCitation] = useState<string>();
    const [activeCitationSourceFile, setActiveCitationSourceFile] = useState<string>();
    const [activeCitationSourceFilePageNumber, setActiveCitationSourceFilePageNumber] = useState<string>();
    const [activeAnalysisPanelTab, setActiveAnalysisPanelTab] = useState<AnalysisPanelTabs | undefined>(undefined);
    const [selectedFolders, setSelectedFolders] = useState<string[]>([]);
    const [selectedTags, setSelectedTags] = useState<ITag[]>([]);

    const [selectedAnswer, setSelectedAnswer] = useState<number>(0);
    const [answers, setAnswers] = useState<[user: string, response: ChatResponse][]>([]);
    const [answerStream, setAnswerStream] = useState<ReadableStream | undefined>(undefined);
    const [abortController, setAbortController] = useState<AbortController | undefined>(undefined);

    const [open, setOpen] = useState(false);
    const handleClose = () => setOpen(false);
    const [analysisPanelModal, setAnalysisPanelModal] = useState(false);
    const handleCloseAnalysisPanelModal = () => setAnalysisPanelModal(false);
    const isMobile = useMobileScreen();
    const [modelName, setModelName] = useState<any>();

    const [selectedFiles, setSelectedFiles] = useState<string[]>([]);
    const [retriverFeature, setRetriverFeature] = useState<any>();
    const [queryTransformationKey, setQueryTransformationKey] = useState<any>();
    const [sourceDateKey, setSourceDateKey] = useState<any>();
    const [chatHistoryIndex, setChatHistoryIndex] = useState();
    const [conversationId, setConversationId] = useState<string>();

    const [retriverTooltip, setRetriverTooltip] = useState(
        "Combined full text with semantic vector search for a comprehensive retrieval. Optimal for most and for a balanced precision & recall."
    );
    const [queryTooltip, setQueryTooltip] = useState(
        "Creates a search query based on conversation history and the new question. Optimal for enhanced retrieval."
    );

    const hostStyles: Partial<ITooltipHostStyles> = { root: { display: "inline-block" } };
    const [enableCompositeScore, setEnableCompositeScore] = useState<boolean>(false);
    const [ragData, setRagData] = useState<any>([]);
    const [scoreData, getRagData] = useState<any>([]);
    const [isRagPanelOpen, setIsRagPanelOpen] = useState(false);
    const [isAnalysisPanelOpen, setIsAnalysisPanelOpen] = useState<boolean>(false);

    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [error, setError] = useState<unknown>();
    const [loader, setLoader] = useState<boolean>(false);
    const [answerLoadedForHistory, setAnswerLoadedForHistory] = useState(false);

    async function fetchFeatureFlags() {
        try {
            //  const fetchedFeatureFlags = await getFeatureFlags();
            // setFeatureFlags(fetchedFeatureFlags);
        } catch (error) {
            // Handle the error here
            console.log(error);
        }
    }

    useEffect(() => {
        if (envConfig?.document_retriever_count !== undefined) {
            setRetrieveCount(envConfig.document_retriever_count);
        }
    }, [envConfig?.document_retriever_count]);

    const getUserId = (): string => {
        return userDetails.user_id ? userDetails.user_id : AppConstants.userId;
    };
    const getIpAddress = (): string => {
        return userDetails.ip_address ? userDetails.ip_address : "";
    };
    const makeApiRequest = async (
        question: string,
        approach: Approaches,
        work_citation_lookup: { [key: string]: { citation: string; source_path: string; page_number: string } },
        web_citation_lookup: { [key: string]: { citation: string; source_path: string; page_number: string } },
        thought_chain: { [key: string]: string }
    ) => {
        lastQuestionRef.current = question;
        lastQuestionWorkCitationRef.current = work_citation_lookup;
        lastQuestionWebCitiationRef.current = web_citation_lookup;
        lastQuestionThoughtChainRef.current = thought_chain;
        setActiveApproach(approach);

        setAnswerLoadedForHistory(false);
        error && setError(undefined);
        setIsLoading(true);
        setActiveCitation(undefined);
        setActiveAnalysisPanelTab(undefined);

        try {
            const history: ChatTurn[] = answers.map(a => ({ user: a[0], bot: a[1].answer }));
            const request: ChatRequestV2 = {
                history: [...history, { user: question, bot: undefined }],
                approach: approach,
                overrides: {
                    promptTemplate: promptTemplate.length === 0 ? undefined : promptTemplate,
                    excludeCategory: excludeCategory.length === 0 ? undefined : excludeCategory,
                    top: retrieveCount,
                    useSemanticRanker: useSemanticRanker,
                    enableCompositeScore: enableCompositeScore,
                    useEnrichedEmbeddings: useEnrichedEmbeddings,
                    useMultiVectorQuery: useMultiVectorQuery,
                    queryTransformationKey: queryTransformationKey ? queryTransformationKey.key : envConfig?.query_transformation_type[0]?.key || "",
                    sourceDateKey: sourceDateKey ? sourceDateKey.key : "",
                    retriverFeature: retriverFeature ? retriverFeature.key : envConfig?.retriever_feature[0]?.key || "",
                    semanticCaptions: useSemanticCaptions,
                    suggestFollowupQuestions: useSuggestFollowupQuestions,
                    userPersona: userPersona,
                    systemPersona: systemPersona,
                    aiPersona: aiPersona,
                    responseLength: responseLength,
                    responseTemp: responseTemp,
                    selectedFolders: selectedFolders.includes("selectAll") ? "All" : selectedFolders.length == 0 ? "All" : selectedFolders.join(","),
                    selectedTags: selectedTags.map(tag => tag.name).join(","),
                    selectedFiles: selectedFiles.includes("selectAll") ? "All" : selectedFiles.length == 0 ? "All" : selectedFiles.join(","),
                    modelName: modelName
                        ? modelName.key
                        : envConfig?.advanced_settings[0].use_lite_llm === false
                        ? ""
                        : envConfig?.model_collection[0]?.key || "",
                    semanticRanker: true
                },
                citation_lookup: {},
                thought_chain: thought_chain,
                userId: getUserId(),
                ipAddress: getIpAddress(),
                conversationId: conversationId
            };

            const temp: ChatResponse = {
                answer: "",
                thoughts: "",
                data_points: [],
                approach: approach,
                thought_chain: {
                    work_response: "",
                    web_response: ""
                },
                work_citation_lookup: {},
                web_citation_lookup: {},
                citation_lookup: {},
                conversation_id: "",
                message_id: "",
                latency: "",
                model: "",
                usage: { total_tokens: 0 }, //TODO
                feedback_type: "",
                scores: {}
            };

            setAnswers([...answers, [question, temp]]);
            const controller = new AbortController();
            setAbortController(controller);
            const signal = controller.signal;
            const result = await chatApiV2(request, signal);
            if (!result.body) {
                throw Error("No response body");
            }
            setAnswerStream(result.body);
        } catch (e) {
            setStreamIsProcessed();
            setError(e);
        }
    };
    /**
     * function identify the Stream is ready
     * @param status
     */
    const setStreamReady = () => {
        //setIsLoading(false);
        chatMessageStreamEnd.current?.scrollIntoView({ behavior: "smooth", block: "end", inline: "nearest" });
    };
    /**
     * function identify the Stream is Processed
     * @param status
     */
    const setStreamIsProcessed = () => {
        setIsLoading(false);
        chatMessageStreamEnd.current?.scrollIntoView({ behavior: "smooth", block: "end", inline: "nearest" });
    };

    const clearChat = () => {
        lastQuestionRef.current = "";
        lastQuestionWorkCitationRef.current = {};
        lastQuestionWebCitiationRef.current = {};
        lastQuestionThoughtChainRef.current = {};
        error && setError(undefined);
        setActiveCitation(undefined);
        setActiveAnalysisPanelTab(undefined);
        setAnswers([]);
        setConversationId(undefined);
        setIsChatHistoryPanelOpen(false);
        setChatHistoryIndex(undefined);
        setIsAtBottom(true);
    };

    const chatHistory = async () => {
        setChatHistoryLoaded(true);
        const history: any = await chatHistoryapi("", getUserId());
        const data = history.history.conversation || [];
        setChatHistory(data);
        setChatHistoryLoaded(false);
    };

    const onResponseLengthChange = (_ev: any) => {
        for (let node of _ev.target.parentNode.childNodes) {
            if (node.value == _ev.target.value) {
                switch (node.value) {
                    case "1024":
                        node.className = `${rlbgstyles.buttonleftactive}`;
                        break;
                    case "2048":
                        node.className = `${rlbgstyles.buttonmiddleactive}`;
                        break;
                    case "3072":
                        node.className = `${rlbgstyles.buttonrightactive}`;
                        break;
                    default:
                        //do nothing
                        break;
                }
            } else {
                switch (node.value) {
                    case "1024":
                        node.className = `${rlbgstyles.buttonleft}`;
                        break;
                    case "2048":
                        node.className = `${rlbgstyles.buttonmiddle}`;
                        break;
                    case "3072":
                        node.className = `${rlbgstyles.buttonright}`;
                        break;
                    default:
                        //do nothing
                        break;
                }
            }
        }
        // the or value here needs to match the default value assigned to responseLength above.
        setResponseLength((_ev.target.value as number) || 2048);
    };

    const onResponseTempChange = (_ev: any) => {
        for (let node of _ev.target.parentNode.childNodes) {
            if (node.value == _ev.target.value) {
                switch (node.value) {
                    case "1.0":
                        node.className = `${rtbgstyles.buttonleftactive}`;
                        break;
                    case "0.6":
                        node.className = `${rtbgstyles.buttonmiddleactive}`;
                        break;
                    case "0":
                        node.className = `${rtbgstyles.buttonrightactive}`;
                        break;
                    default:
                        //do nothing
                        break;
                }
            } else {
                switch (node.value) {
                    case "1.0":
                        node.className = `${rtbgstyles.buttonleft}`;
                        break;
                    case "0.6":
                        node.className = `${rtbgstyles.buttonmiddle}`;
                        break;
                    case "0":
                        node.className = `${rtbgstyles.buttonright}`;
                        break;
                    default:
                        //do nothing
                        break;
                }
            }
        }
        // the or value here needs to match the default value assigned to responseLength above.
        setResponseTemp((_ev.target.value as number) || 0.6);
    };

    const onChatModeChange = (_ev: any) => {
        abortController?.abort();
        const chatMode = (_ev.target.value as ChatMode) || ChatMode.WorkOnly;
        setChatMode(chatMode);
        setDefaultApproach(Approaches.ReadRetrieveRead);
        setActiveApproach(Approaches.ReadRetrieveRead);
        clearChat();
    };

    const handleToggle = () => {
        defaultApproach == Approaches.ReadRetrieveRead;
    };

    useEffect(() => {
        fetchFeatureFlags();
    }, []);
    useEffect(() => {
        chatMessageStreamEnd.current?.scrollIntoView({ behavior: "smooth" });
    }, [isLoading]);

    const onRetrieveCountChange = (_ev?: React.SyntheticEvent<HTMLElement, Event>, newValue?: string) => {
        setRetrieveCount(parseInt(newValue || "5"));
    };

    const onUserPersonaChange = (_ev?: React.FormEvent<HTMLInputElement | HTMLTextAreaElement>, newValue?: string) => {
        setUserPersona(newValue || "");
    };

    const onSystemPersonaChange = (_ev?: React.FormEvent<HTMLInputElement | HTMLTextAreaElement>, newValue?: string) => {
        setSystemPersona(newValue || "");
    };

    const onUseSuggestFollowupQuestionsChange = (_ev?: React.FormEvent<HTMLElement | HTMLInputElement>, checked?: boolean) => {
        setUseSuggestFollowupQuestions(!!checked);
    };

    const onExampleClicked = (example: string) => {
        makeApiRequest(example, Approaches.ReadRetrieveRead, {}, {}, {});
    };

    const onShowCitation = (citation: string, citationSourceFile: string, citationSourceFilePageNumber: string, index: number) => {
        setAnalysisPanelModal(true); //T TODO
        setIsAnalysisPanelOpen(true); //T TODO

        if (activeCitation === citation && activeAnalysisPanelTab === AnalysisPanelTabs.CitationTab && selectedAnswer === index) {
            setActiveAnalysisPanelTab(undefined);
        } else {
            setActiveCitation(citation);
            setActiveCitationSourceFile(citationSourceFile);
            setActiveCitationSourceFilePageNumber(citationSourceFilePageNumber);
            setActiveAnalysisPanelTab(AnalysisPanelTabs.CitationTab);
        }
        setIsChatHistoryPanelOpen(false);
        setSelectedAnswer(index);
    };

    const onToggleTab = (tab: AnalysisPanelTabs, index: number) => {
        setAnalysisPanelModal(true); //T TODO
        setIsAnalysisPanelOpen(true); //T TODO
        if (activeAnalysisPanelTab === tab && selectedAnswer === index) {
            setActiveAnalysisPanelTab(undefined);
        } else {
            setActiveAnalysisPanelTab(tab);
        }
        setIsChatHistoryPanelOpen(false);
        setSelectedAnswer(index);
    };

    const onSelectedKeyChanged = (selectedFolders: string[]) => {
        setSelectedFolders(selectedFolders);
    };

    const onSelectedTagsChange = (selectedTags: ITag[]) => {
        setSelectedTags(selectedTags);
    };

    useEffect(() => {
        // Hide Scrollbar for this page
        document.body.classList.add("chat-overflow-hidden-body");
        // Do not apply to other pages
        return () => {
            document.body.classList.remove("chat-overflow-hidden-body");
        };
    }, []);

    const updateAnswerAtIndex = (index: number, response: ChatResponse) => {
        setAnswers(currentAnswers => {
            const updatedAnswers = [...currentAnswers];
            updatedAnswers[index] = [updatedAnswers[index][0], response];
            return updatedAnswers;
        });
        setConversationId(response?.conversation_id);
    };

    const removeAnswerAtIndex = (index: number) => {
        const newItems = answers.filter((item, idx) => idx !== index);
        setAnswers(newItems);
    };

    const onSelectedFileChanged = (selectedFiles: string[]) => {
        setSelectedFiles(selectedFiles);
    };

    const customCheckboxStyles = mergeStyles({
        selectors: {
            "& .ms-Checkbox-checkbox": {
                borderColor: `${envConfig?.application_theme_color}!important`
            },
            "& .ms-Checkbox.is-checked .ms-Checkbox-checkbox": {
                borderColor: `${envConfig?.application_theme_color} !important`,
                backgroundColor: `${envConfig?.application_theme_color} !important`
            },
            "& .ms-Checkbox.is-checked .ms-Checkbox-checkmark": {
                color: "white !important"
            },
            "& .ms-Checkbox-checkbox:hover": {
                borderColor: `${envConfig?.application_theme_color} !important`
            },
            "& .ms-Checkbox-checkbox:hover .ms-Checkbox-checkmark": {
                color: "white !important"
            }
        }
    });

    const onModelNameChange = (event: React.FormEvent<IComboBox>, option?: IComboBoxOption): void => {
        setModelName(option);
    };

    const onQueryTransformationChange = (event: React.FormEvent<IComboBox>, option?: IComboBoxOption): void => {
        setQueryTransformationKey(option);
        const tooltipInfo: any = {
            normalized: "Creates a search query based on conversation history and the new question. Optimal for enhanced retrieval.",
            sub_query:
                "Breaks down the main query into smaller parts. Intermediate responses from each combined into a final answer. Optimal for generation from multiple retrieved documents.",
            hyde: "Creates a theoretical document to answer the query, instead of from the search index. Optimal for creative and open ended questions."
        };
        const key = option?.key || "";
        setQueryTooltip(tooltipInfo[key]);
    };

    const onSourceDateChange = (event: React.FormEvent<IComboBox>, option?: IComboBoxOption): void => {
        setSourceDateKey(option);
    };

    const onRetriverFeatureChange = (event: React.FormEvent<IComboBox>, option?: IComboBoxOption): void => {
        setRetriverFeature(option);
        const tooltipInfo: any = {
            default: "Combined full text with semantic vector search for a comprehensive retrieval. Optimal for most and for a balanced precision & recall.",
            multi_vector_query: "Sends multiple queries targeting multiple vector fields to improve retrieval accuracy. Optimal for complex, nuanced queries."
        };
        const key = option?.key || "";
        setRetriverTooltip(tooltipInfo[key]);
    };

    const onEnableCompositeScore = (_ev?: React.FormEvent<HTMLElement | HTMLInputElement>, checked?: boolean) => {
        setEnableCompositeScore(!!checked);
    };
    const [isAtBottom, setIsAtBottom] = useState<boolean>(true);
    const chatMessageStreamRef = useRef<HTMLDivElement>(null);
    const checkScrollPosition = () => {
        if (!chatMessageStreamRef.current) return;

        const threshold = 10;
        const isUserAtBottom =
            chatMessageStreamRef.current.scrollHeight - chatMessageStreamRef.current.scrollTop <= chatMessageStreamRef.current.clientHeight + threshold;

        setIsAtBottom(isUserAtBottom);
    };

    const handleScroll = () => {
        checkScrollPosition();
    };

    const selectedConversationThread = async (conversationThread: any) => {
        if (isAnalysisPanelOpen) {
            // T TODO
            setActiveAnalysisPanelTab(undefined);
            setIsAnalysisPanelOpen(false);
        }

        setLoader(true);
        const history: any = await chatHistoryapi(conversationThread[0]);

        const msg = history.history.conversation[0].messages.map((e: any) => {
            if (e.role == "user") {
                return e.answer;
            } else {
                return {
                    answer: e.answer,
                    citation_lookup: e.citation_lookup,
                    data_points: e.data_points,
                    thoughts: e.thoughts,
                    scores: e.scores,
                    usage: e.usage,
                    latency: e.latency,
                    conversation_id: e.conversation_id,
                    message_id: e.message_id,
                    feedback_type: e.feedback_type,
                    model: e.model,
                    approach: "rrr"
                };
            }
        });

        const threadData = msg.reduce((acc: any[], curr: any, i: number) => {
            if (!(i % 2)) {
                acc.push(msg.slice(i, i + 2));
            }
            return acc;
        }, []);
        setAnswers(threadData);
        setConversationId(conversationThread[0]);
        setLoader(false);

        setAnswerLoadedForHistory(true);

        lastQuestionRef.current = " ";
        setTimeout(() => {
            checkScrollPosition();
        }, 100);
    };

    const deleteConversationThread = async (e: any, id: any) => {
        e.stopPropagation();
        e.nativeEvent.stopImmediatePropagation();
        await deleteChatThread(id);
        const data = history.filter(function (d: { id: any }) {
            return d.id != id;
        });

        setChatHistory(data);
        lastQuestionRef.current = "";
        error && setError(undefined);
        setActiveCitation(undefined);
        setActiveAnalysisPanelTab(undefined);
        setAnswers([]);
        setConversationId(undefined);
    };

    const onShowCompositeScore = (a: any, b: any, c: any) => {
        setOpen(true);
        setEvalScore([a, b, c]);
    };

    const ragEvaluationScore = () => {
        setIsRagPanelOpen(!isRagPanelOpen);

        const filteredData = scoreData?.filter((i: any) => {
            const retriverFeatureName: any = retriverFeature ? retriverFeature.key : "default";
            const queryTransformationName: any = queryTransformationKey ? queryTransformationKey.key : "simple";

            if (
                i.n_retriever_results == retrieveCount &&
                i.retriever_feature == retriverFeatureName &&
                i.query_transformation_type == queryTransformationName &&
                i.use_semantic_reranking == useSemanticRanker
            )
                return i;
        });
        setRagData([...filteredData, scoreData[0]]);
    };
    useEffect(() => {
        const chatMessageStream = chatMessageStreamRef.current;
        if (chatMessageStream) {
            chatMessageStream.addEventListener("scroll", handleScroll, { passive: true });
        }

        return () => {
            if (chatMessageStream) {
                chatMessageStream.removeEventListener("scroll", handleScroll);
            }
        };
    }, [answers]);

    const scrollToBottom = () => {
        if (chatMessageStreamRef.current) {
            chatMessageStreamRef.current.scrollTop = chatMessageStreamRef.current.scrollHeight;
        }
    }; 
    async function fetchRagScores() {
        try {
            const v = await getRagScores();
            if (!v) {
                return null;
            }
            getRagData(v.response);
        } catch (error) {
            // Handle the error here
            console.log(error);
        }
    }

   

    useEffect(() => {
        if (envConfig?.advanced_settings[0]?.show_rag_eval_score) {
            fetchRagScores();
        }
    }, []);

    const onSemanticRankerChange = (_ev?: React.FormEvent<HTMLElement | HTMLInputElement>, checked?: boolean) => {
        setUseSemanticRanker(!!checked);
    };
    return (

   
        <div className={styles.container}>
            
     
            <div className={styles.commandsContainer}>
                <ClearChatButton
                    className={styles.commandButton + " " + (isLoading ? styles.cursorDisabled : "")}
                    onClick={!isLoading ? clearChat : () => {}}
                    disabled={!lastQuestionRef.current || isLoading}
                />
                {/* {isMobile ? (
                    <SettingsButton className={styles.commandButton} onClick={() => setAdjustPanelModal(!adjustPanelModal)} />
                ) : (
                    <SettingsButton className={styles.commandButton} onClick={() => setIsConfigPanelOpen(!isConfigPanelOpen)} />
                )} */}
              {/*   <SettingsButton className={styles.commandButton} onClick={() => setAdjustPanelModal(!adjustPanelModal)} /> */}
                <div
                    className={styles.chatHistoryText + " " + (isLoading ? styles.cursorDisabled : "")}
                    onClick={() => {
                        if (!isLoading) {
                            setIsChatHistoryPanelOpen(!isChatHistoryOpen);
                            chatHistory();
                        }
                    }}
                >
                    <History24Regular />
                    <span>{isChatHistoryOpen ? "Hide history" : "Show history"}</span>
                </div>
                {envConfig?.advanced_settings[0]?.show_rag_eval_score && (
                    <div
                        className={styles.ragEvalButton}
                        onClick={() => {
                            ragEvaluationScore();
                        }}
                    >
                        <svg width="24" height="24" viewBox="0 0 110 123" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <g clip-path="url(#clip0_9_715)">
                                <path
                                    d="M82.42 73.514C88.361 73.514 93.75 75.932 97.652 79.819C101.555 83.723 103.958 89.096 103.958 95.053C103.958 99.399 102.662 103.459 100.449 106.84L109.773 117.002L103.341 122.879L94.349 112.988C90.936 115.263 86.828 116.59 82.419 116.59C76.478 116.59 71.089 114.174 67.186 110.285C63.283 106.383 60.88 101.01 60.88 95.053C60.88 89.112 63.298 83.723 67.186 79.819C71.09 75.916 76.462 73.514 82.42 73.514ZM28.849 79.506C27.261 79.506 25.973 78.188 25.973 76.6C25.973 74.983 27.262 73.696 28.849 73.696H47.602C49.19 73.696 50.478 75.012 50.478 76.6C50.478 78.219 49.19 79.506 47.602 79.506H28.849ZM28.849 38.645C27.261 38.645 25.973 37.357 25.973 35.769C25.973 34.182 27.262 32.894 28.849 32.894H66.894C68.482 32.894 69.77 34.182 69.77 35.769C69.77 37.357 68.482 38.645 66.894 38.645H28.849ZM51.455 106.588C53.043 106.588 54.331 107.875 54.331 109.463C54.331 111.051 53.043 112.34 51.455 112.34H6.711C4.854 112.34 3.176 111.59 1.978 110.361C0.749 109.164 0 107.486 0 105.629V6.71C0 4.853 0.749 3.175 1.978 1.977C3.206 0.749 4.854 0 6.711 0H89.003C90.86 0 92.538 0.749 93.736 1.978C94.964 3.206 95.713 4.853 95.713 6.711V65.083C95.713 66.671 94.425 67.96 92.837 67.96C91.25 67.96 89.961 66.671 89.961 65.083V6.71C89.961 6.44 89.842 6.231 89.691 6.051C89.511 5.871 89.272 5.781 89.033 5.781H6.741C6.471 5.781 6.262 5.901 6.082 6.051C5.902 6.231 5.812 6.47 5.812 6.71V105.628C5.812 105.898 5.932 106.107 6.082 106.286C6.262 106.466 6.501 106.556 6.741 106.556H51.485L51.455 106.588ZM28.849 59.075C27.261 59.075 25.973 57.787 25.973 56.2C25.973 54.612 27.262 53.324 28.849 53.324H66.894C68.482 53.324 69.77 54.612 69.77 56.2C69.77 57.787 68.482 59.075 66.894 59.075H28.849ZM94.811 82.66C91.641 79.49 87.255 77.521 82.42 77.521C77.584 77.521 73.198 79.49 70.028 82.66C66.857 85.832 64.888 90.217 64.888 95.053C64.888 99.887 66.857 104.274 70.028 107.444C73.198 110.614 77.584 112.583 82.42 112.583C87.255 112.583 91.641 110.614 94.811 107.444C97.982 104.274 99.951 99.887 99.951 95.053C99.95 90.217 97.981 85.832 94.811 82.66Z"
                                    fill="white"
                                />
                            </g>
                            <defs>
                                <clipPath id="clip0_9_715">
                                    <rect width="109.773" height="122.879" fill="white" />
                                </clipPath>
                            </defs>
                        </svg>
                        <span>RAG Evaluation</span>
                    </div>
                )} 
            </div>
            
           
            <div className={styles.chatRoot}>
                <div className={styles.chatContainer}>
                    {!lastQuestionRef.current ? (
                        <div className={styles.chatEmptyState}>
                            {/* <SparkleFilled fontSize={"120px"} primaryFill={"rgba(115, 118, 225, 1)"} aria-hidden="true" aria-label="Chat logo" /> */}
                            <h1 className={styles.chatEmptyStateTitle} style={{ color: envConfig?.application_theme_color }}>
                                {envConfig?.application_heading}
                            </h1>
                            <span className={styles.chatEmptyObjectives}>{envConfig?.subtitle}</span>
                            {/* <h2 className={styles.chatEmptyStateSubtitle}>Ask anything or try an example</h2> */}
                            <ExampleList examples={envConfig?.questions} onExampleClicked={onExampleClicked} />
                        </div>
                    ) : (
                        <div className={styles.chatMessageStream} ref={chatMessageStreamRef}>
                            {loader && (
                                <Backdrop sx={{ color: "#fff", zIndex: 100 }} open={true}>
                                    <CircularProgress color="inherit" />
                                </Backdrop>
                            )}

                            {answers.map((answer, index) => (
                                <div key={index}>
                                    <UserChatMessage
                                        message={answer[0]}
                                        envConfig={envConfig}
                                        onEditSubmit={msg => makeApiRequest(msg, Approaches.ReadRetrieveRead, {}, {}, {})}
                                    />
                                    <div className={styles.chatMessageGpt}>
                                        <Answer
                                            key={index}
                                            answer={answer[1]}
                                            answerStream={answerStream}
                                            setError={error => {
                                                setError(error);
                                                removeAnswerAtIndex(index);
                                            }}
                                            setAnswer={response => updateAnswerAtIndex(index, response)}
                                            isSelected={selectedAnswer === index && activeAnalysisPanelTab !== undefined}
                                            onCitationClicked={(c, s, p) => onShowCitation(c, s, p, index)}
                                            onThoughtProcessClicked={() => onToggleTab(AnalysisPanelTabs.ThoughtProcessTab, index)}
                                            onCompositeScoreClicked={(a, b, c) => onShowCompositeScore(a, b, c)}
                                            onSupportingContentClicked={() => onToggleTab(AnalysisPanelTabs.SupportingContentTab, index)}
                                            onFollowupQuestionClicked={q =>
                                                makeApiRequest(
                                                    q,
                                                    answer[1].approach,
                                                    answer[1].work_citation_lookup,
                                                    answer[1].web_citation_lookup,
                                                    answer[1].thought_chain
                                                )
                                            }
                                            showFollowupQuestions={useSuggestFollowupQuestions}
                                            onAdjustClick={() => {
                                                setAdjustPanelModal(!adjustPanelModal);
                                                setIsConfigPanelOpen(!isConfigPanelOpen);
                                            }}
                                            onRegenerateClick={() =>
                                                makeApiRequest(
                                                    answers[index][0],
                                                    answer[1].approach,
                                                    answer[1].work_citation_lookup,
                                                    answer[1].web_citation_lookup,
                                                    answer[1].thought_chain
                                                )
                                            }
                                            updateFeedback={id => selectedConversationThread(id)}
                                            isStreamRequested={isLoading}
                                            setStreamReady={setStreamReady}
                                            setStreamIsProcessed={setStreamIsProcessed}
                                            envConfig={envConfig}
                                            answerLoadedForHistory={answerLoadedForHistory}
                                        />
                                    </div>
                                </div>
                            ))}
                            {error ? (
                                <>
                                    <UserChatMessage
                                        message={lastQuestionRef.current}
                                        envConfig={envConfig}
                                        onEditSubmit={msg => makeApiRequest(msg, Approaches.ReadRetrieveRead, {}, {}, {})}
                                    />
                                    <div className={styles.chatMessageGptMinWidth}>
                                        <AnswerError
                                            error={error.toString()}
                                            onRetry={() =>
                                                makeApiRequest(
                                                    lastQuestionRef.current,
                                                    Approaches.ReadRetrieveRead,
                                                    lastQuestionWorkCitationRef.current,
                                                    lastQuestionWebCitiationRef.current,
                                                    lastQuestionThoughtChainRef.current
                                                )
                                            }
                                        />
                                    </div>
                                </>
                            ) : null}
                            <div ref={chatMessageStreamEnd} />
                        </div>
                    )}

                    {!isAtBottom && (
                        <div onClick={scrollToBottom} className={styles.scrollToBottomButton}>
                            <svg width="15px" height="15px" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path
                                    fill-rule="evenodd"
                                    clip-rule="evenodd"
                                    d="M12 3C12.5523 3 13 3.44772 13 4V17.5858L18.2929 12.2929C18.6834 11.9024 19.3166 11.9024 19.7071 12.2929C20.0976 12.6834 20.0976 13.3166 19.7071 13.7071L12.7071 20.7071C12.3166 21.0976 11.6834 21.0976 11.2929 20.7071L4.29289 13.7071C3.90237 13.3166 3.90237 12.6834 4.29289 12.2929C4.68342 11.9024 5.31658 11.9024 5.70711 12.2929L11 17.5858V4C11 3.44772 11.4477 3 12 3Z"
                                    fill="#000000"
                                />
                            </svg>
                        </div>
                    )}
                    <div className={styles.chatInput}>
                        {activeChatMode == ChatMode.WorkPlusWeb && (
                            <div className={styles.chatInputWarningMessage}>
                                <div>
                                    Questions will be answered by default from Work
                                    <BuildingMultipleFilled fontSize={"20px"} primaryFill={"rgba(27, 74, 239, 1)"} aria-hidden="true" aria-label="Work Data" />
                                </div>
                            </div>
                        )}
                        <QuestionInput
                            clearOnSend
                            placeholder="Type a new question...."
                            disabled={isLoading}
                            onSend={question => makeApiRequest(question, Approaches.ReadRetrieveRead, {}, {}, {})}
                            onAdjustClick={() => setIsConfigPanelOpen(!isConfigPanelOpen)}
                            onInfoClick={() => setIsInfoPanelOpen(!isInfoPanelOpen)}
                            showClearChat={true}
                            onClearClick={clearChat}
                            onRegenerateClick={() => makeApiRequest(lastQuestionRef.current, Approaches.ReadRetrieveRead, {}, {}, {})}
                        />
                    </div>
                </div>

                {answers.length > 0 && activeAnalysisPanelTab && isAnalysisPanelOpen && (
                    <>
                        {isMobile ? (
                            <Modal open={analysisPanelModal} onClose={handleCloseAnalysisPanelModal}>
                                <>
                                    <div className={styles.closeIcon}>
                                        <svg
                                            onClick={handleCloseAnalysisPanelModal}
                                            width="15"
                                            height="15"
                                            viewBox="0 0 26 26"
                                            fill="none"
                                            xmlns="http://www.w3.org/2000/svg"
                                        >
                                            <path
                                                d="M25.25 3.2175L22.7825 0.75L13 10.5325L3.2175 0.75L0.75 3.2175L10.5325 13L0.75 22.7825L3.2175 25.25L13 15.4675L22.7825 25.25L25.25 22.7825L15.4675 13L25.25 3.2175Z"
                                                fill="#343842"
                                            />
                                        </svg>
                                    </div>
                                    <AnalysisPanelV2
                                        className={styles.chatAnalysisPanel}
                                        activeCitation={activeCitation}
                                        sourceFile={activeCitationSourceFile}
                                        pageNumber={activeCitationSourceFilePageNumber}
                                        onActiveTabChanged={x => onToggleTab(x, selectedAnswer)}
                                        citationHeight="760px"
                                        answer={answers[selectedAnswer][1]}
                                        activeTab={activeAnalysisPanelTab}
                                    />
                                </>
                            </Modal>
                        ) : (
                            <div style={{ width: "50%" }}>
                                <AnalysisPanelV2
                                    className={styles.chatAnalysisPanel}
                                    activeCitation={activeCitation}
                                    sourceFile={activeCitationSourceFile}
                                    pageNumber={activeCitationSourceFilePageNumber}
                                    onActiveTabChanged={x => onToggleTab(x, selectedAnswer)}
                                    citationHeight="760px"
                                    answer={answers[selectedAnswer][1]}
                                    activeTab={activeAnalysisPanelTab}
                                />
                                <div
                                    className={styles.closeIcon}
                                    style={{ position: "absolute", top: "60px", right: "2%", cursor: "pointer", zIndex: 3 }}
                                    onClick={() => {
                                        setActiveAnalysisPanelTab(undefined);
                                    }}
                                >
                                    <svg width="15" height="15" viewBox="0 0 26 26" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M25.25 3.2175L22.7825 0.75L13 10.5325L3.2175 0.75L0.75 3.2175L10.5325 13L0.75 22.7825L3.2175 25.25L13 15.4675L22.7825 25.25L25.25 22.7825L15.4675 13L25.25 3.2175Z"
                                            fill="#343842"
                                        />
                                    </svg>
                                </div>
                            </div>
                        )}
                    </>
                )}

                {!isMobile && isChatHistoryOpen && (
                    <Panel isOpen={isChatHistoryOpen} onDismiss={() => setIsChatHistoryPanelOpen(false)} isBlocking={false} style={{ width: "100%" }}>
                        <ChatHistory
                            id={conversationId}
                            selectedConversationThread={selectedConversationThread}
                            history={history}
                            isChatHistoryLoaded={isChatHistoryLoaded}
                            deleteConversationThread={deleteConversationThread}
                        />
                    </Panel>
                )}

                {isMobile && isChatHistoryOpen && (
                    <Panel isOpen={isChatHistoryOpen} onDismiss={() => setIsChatHistoryPanelOpen(false)} isBlocking={false} style={{ width: "85%" }}>
                        <ChatHistory
                            id={conversationId}
                            selectedConversationThread={selectedConversationThread}
                            history={history}
                            deleteConversationThread={deleteConversationThread}
                        />
                    </Panel>
                )}
                <Modal open={adjustPanelModal} onClose={handleCloseAdjustPanelModal}>
                    <Box
                        sx={{
                            position: "absolute" as "absolute",
                            top: "50%",
                            left: "50%",
                            transform: "translate(-50%, -50%)",
                            width: "90%",
                            maxWidth: "1120px",
                            bgcolor: "background.paper",
                            boxShadow: 24,
                            outline: 0,
                            p: 2,
                            overflowY: "auto",
                            height: "95%",
                            maxHeight: isMobile ? "940px" : "600px",
                            borderRadius: 3.75,
                            paddingTop: 0
                        }}
                    >
                        <div className={styles.AdjustContainer}>
                            <div style={{ textAlign: "end" }}>
                                <svg
                                    onClick={handleCloseAdjustPanelModal}
                                    width="15"
                                    height="15"
                                    viewBox="0 0 26 26"
                                    fill="none"
                                    xmlns="http://www.w3.org/2000/svg"
                                >
                                    <path
                                        d="M25.25 3.2175L22.7825 0.75L13 10.5325L3.2175 0.75L0.75 3.2175L10.5325 13L0.75 22.7825L3.2175 25.25L13 15.4675L22.7825 25.25L25.25 22.7825L15.4675 13L25.25 3.2175Z"
                                        fill="#343842"
                                    />
                                </svg>
                            </div>
                            <span className={styles.AdjustTitile}>Configure answer generation</span>
                        </div>
                        <div className={styles.groupOne}>
                            <SpinButton
                                className={styles.chatSettingsSeparator}
                                label="Retrieve this many documents from search:"
                                min={1}
                                max={50}
                                defaultValue={retrieveCount.toString()}
                                onChange={onRetrieveCountChange}
                            />
                            <ResponseLengthButtonGroup
                                themeColor={envConfig?.application_theme_color}
                                className={styles.chatSettingsSeparator}
                                onClick={onResponseLengthChange}
                                defaultValue={responseLength}
                            />
                            <ResponseTempButtonGroup
                                themeColor={envConfig?.application_theme_color}
                                className={styles.chatSettingsSeparator}
                                onClick={onResponseTempChange}
                                defaultValue={responseTemp}
                            />
                            {/* <Checkbox styles={checkBoxStyles} label="Controlled checkbox" checked={isChecked} onChange={onChange} /> */}
                            <div className={customCheckboxStyles}>
                                <Checkbox
                                    className={styles.chatSettingsSeparator}
                                    checked={useSuggestFollowupQuestions}
                                    label="Suggest follow-up questions"
                                    onChange={onUseSuggestFollowupQuestionsChange}
                                />
                            </div>
                        </div>
                        <Separator className={styles.chatSettingsSeparator}>Filter search results by</Separator>
                        <div className={styles.groupTwo}>
                            <FolderPicker allowFolderCreation={false} 
                            onSelectedKeyChange={onSelectedKeyChanged} 
                            preSelectedKeys={selectedFolders}
                             />


<FolderPickerNested allowFolderCreation={false} 
                            onSelectedKeyChange={onSelectedKeyChanged} 
                            preSelectedKeys={selectedFolders}
                             />



                            <FileDropdown onFileSelectChange={onSelectedFileChanged} selectedFolders={selectedFolders} preSelectedKeys={selectedFiles} />
                            <TagPickerInline allowNewTags={false} onSelectedTagsChange={onSelectedTagsChange} preSelectedTags={selectedTags} />
                        </div>

                        <Separator className={styles.chatSettingsSeparator}>Advanced settings</Separator>

                        <div className={styles.groupThree}>
                            {envConfig?.advanced_settings[0].use_lite_llm && (
                                <div className={styles.folderArea}>
                                    <div className={styles.folderSelection}>
                                        <ComboBox
                                            label="Model selection:"
                                            selectedKey={modelName ? modelName.key : envConfig?.model_collection[0]?.key || []}
                                            onChange={onModelNameChange}
                                            options={envConfig?.model_collection}
                                        />
                                        <TooltipHost content={"Allows you to specify a model for answer generation"} styles={hostStyles}>
                                            <Info16Regular></Info16Regular>
                                        </TooltipHost>
                                    </div>
                                </div>
                            )}
                            {envConfig?.advanced_settings[0].retriever_feature && (
                                <div className={styles.folderArea}>
                                    <div className={styles.folderSelection}>
                                        <ComboBox
                                            label="Retriever selection:"
                                            selectedKey={retriverFeature ? retriverFeature.key : envConfig?.retriever_feature[0]?.key}
                                            options={envConfig?.retriever_feature}
                                            onChange={onRetriverFeatureChange}
                                        />
                                        <TooltipHost content={queryTooltip} styles={hostStyles}>
                                            <Info16Regular></Info16Regular>
                                        </TooltipHost>
                                    </div>
                                </div>
                            )}

                            {envConfig?.advanced_settings[0].query_transformation_type && (
                                <div className={styles.folderArea}>
                                    <div className={styles.folderSelection}>
                                        <ComboBox
                                            label="Query transformation type selection:"
                                            selectedKey={queryTransformationKey ? queryTransformationKey.key : envConfig?.query_transformation_type[0]?.key}
                                            options={envConfig?.query_transformation_type}
                                            onChange={onQueryTransformationChange}
                                        />
                                        <TooltipHost content={queryTooltip} styles={hostStyles}>
                                            <Info16Regular></Info16Regular>
                                        </TooltipHost>
                                    </div>
                                </div>
                            )}
                            {envConfig?.source_date_range && (
                                <div className={styles.folderArea}>
                                    <div className={styles.folderSelection}>
                                        <ComboBox
                                            placeholder="Select Date"
                                            label="Select source date"
                                            selectedKey={sourceDateKey ? sourceDateKey.key : ""}
                                            options={envConfig?.source_date_range}
                                            onChange={onSourceDateChange}
                                        />
                                        <TooltipHost content={"Date range to filter the corpus data"} styles={hostStyles}>
                                            <Info16Regular></Info16Regular>
                                        </TooltipHost>
                                    </div>
                                </div>
                            )}

                            {envConfig?.advanced_settings[0].show_kpmg_trust_score && (
                                <div className={customCheckboxStyles}>
                                    <Checkbox
                                        className={styles.kpmgTrustScore}
                                        checked={enableCompositeScore}
                                        label="Show KPMG trust score"
                                        onChange={onEnableCompositeScore}
                                    />
                                </div>
                            )}


                        </div>
                    </Box>
                </Modal>

                {envConfig?.advanced_settings[0]?.show_rag_eval_score && (
                    <Panel
                        headerText="RAG evaluation score"
                        isOpen={isRagPanelOpen}
                        isBlocking={false}
                        onDismiss={() => setIsRagPanelOpen(false)}
                        closeButtonAriaLabel="Close"
                        onRenderFooterContent={() => <DefaultButton onClick={() => setIsRagPanelOpen(false)}>Close</DefaultButton>}
                        isFooterAtBottom={true}
                    >
                        {ragData.length > 0 && (
                            <div className={styles.resultspanel}>
                                <div>
                                    {ragData.map(function (i: any, index: number) {
                                        return (
                                            <Accordion
                                                expanded={true}
                                                sx={{
                                                    marginBottom: "10px",
                                                    marginTop: "10px",
                                                    color: "rgb(50, 49, 48)",
                                                    boxShadow: "0 2px 4px #ffffff24,0 0 2px #ffffff1f"
                                                }}
                                            >
                                                <AccordionSummary aria-controls="panel2a-content" id="panel2a-header">
                                                    <Typography>{i?.top_result === true ? "Selection with best score" : "Selected options"}</Typography>
                                                </AccordionSummary>
                                                <AccordionDetails>
                                                    <Typography>
                                                        <div className={styles.ragScore}>
                                                            <label>No. of Retriever results:</label> <span>{i.n_retriever_results}</span>
                                                        </div>
                                                        <div className={styles.ragScore}>
                                                            <label>Retriever feature:</label> <span>{i.retriever_feature}</span>
                                                        </div>
                                                        <div className={styles.ragScore}>
                                                            <label>Query transformation type:</label> <span>{i.query_transformation_type}</span>
                                                        </div>
                                                        <Separator className={styles.chatSettingsSeparator}>Score</Separator>
                                                        <div className={styles.ragScore}>
                                                            <label>Context relevancy:</label> <span>{i.Score_context_relevancy.toFixed(2)}</span>
                                                        </div>
                                                        <div className={styles.ragScore}>
                                                            <label>Context recall:</label> <span>{i.Score_context_recall.toFixed(2)}</span>
                                                        </div>
                                                        <div className={styles.ragScore}>
                                                            <label>Answer relevancy:</label> <span>{i.Score_Answer_Relevancy.toFixed(2)}</span>
                                                        </div>
                                                        <div className={styles.ragScore}>
                                                            <label>Faithfullness:</label> <span>{i.Score_Faithfullness.toFixed(2)}</span>
                                                        </div>
                                                    </Typography>
                                                </AccordionDetails>
                                            </Accordion>
                                        );
                                    })}
                                </div>
                            </div>
                        )}
                    </Panel>
                )}
                <Panel
                    headerText="Information"
                    isOpen={isInfoPanelOpen}
                    isBlocking={false}
                    onDismiss={() => setIsInfoPanelOpen(false)}
                    closeButtonAriaLabel="Close"
                    onRenderFooterContent={() => <DefaultButton onClick={() => setIsInfoPanelOpen(false)}>Close</DefaultButton>}
                    isFooterAtBottom={true}
                >
                    <div className={styles.resultspanel}>
                        <InfoContent />
                    </div>
                </Panel>
                <Modal open={open} onClose={handleClose}>
                    <Box
                        sx={{
                            position: "absolute" as "absolute",
                            top: "50%",
                            left: "50%",
                            transform: "translate(-50%, -50%)",
                            width: "90%",
                            maxWidth: "700px",
                            bgcolor: "background.paper",
                            boxShadow: 24,
                            outline: 0,
                            p: "20px",
                            overflowY: "auto",
                            height: "95%",
                            maxHeight: isMobile ? "940px" : "600px",
                            borderRadius: 3.75
                        }}
                    >
                        <div className={styles.trustScoreContainer}>
                            <div style={{ textAlign: "end" }}>
                                <svg onClick={handleClose} width="15" height="15" viewBox="0 0 26 26" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M25.25 3.2175L22.7825 0.75L13 10.5325L3.2175 0.75L0.75 3.2175L10.5325 13L0.75 22.7825L3.2175 25.25L13 15.4675L22.7825 25.25L25.25 22.7825L15.4675 13L25.25 3.2175Z"
                                        fill="#343842"
                                    />
                                </svg>
                            </div>
                            <Typography id="modal-modal-title" variant="h6" component="h2" sx={{ color: "rgba(14, 31, 88, 1)" }}>
                                KPMG Trust Score Breakdown
                            </Typography>
                        </div>
                        <Typography id="modal-modal-description" sx={{ mt: 2 }}>
                            <div>
                                <div className={styles.scoreType}>
                                    <span>Context Relevancy Score</span>
                                    <span>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="20" viewBox="0 0 20 20" fill="none">
                                            <path
                                                d="M16.9701 7.12631L15.9451 8.66797C16.4394 9.65387 16.6814 10.747 16.6495 11.8494C16.6175 12.9518 16.3125 14.0291 15.7618 14.9846H4.2118C3.4961 13.7431 3.19954 12.3039 3.36608 10.8805C3.53262 9.45715 4.15339 8.12533 5.13636 7.08249C6.11934 6.03966 7.41219 5.34134 8.82325 5.09105C10.2343 4.84076 11.6885 5.05183 12.9701 5.69297L14.5118 4.66797C12.9422 3.66149 11.0804 3.21048 9.2242 3.38709C7.36801 3.5637 5.62467 4.35772 4.27304 5.64215C2.92141 6.92658 2.0396 8.6272 1.76865 10.472C1.49769 12.3168 1.85326 14.1991 2.77846 15.818C2.92389 16.0699 3.1327 16.2793 3.38416 16.4255C3.63561 16.5717 3.92094 16.6495 4.2118 16.6513H15.7535C16.0471 16.6525 16.3359 16.576 16.5906 16.4297C16.8452 16.2833 17.0566 16.0723 17.2035 15.818C17.9713 14.4879 18.3566 12.9715 18.3169 11.4363C18.2772 9.901 17.814 8.40657 16.9785 7.11797L16.9701 7.12631Z"
                                                fill="#ffffff"
                                            />
                                            <path
                                                d="M8.8118 12.8263C8.96659 12.9813 9.1504 13.1042 9.35273 13.1881C9.55506 13.2719 9.77194 13.3151 9.99096 13.3151C10.21 13.3151 10.4269 13.2719 10.6292 13.1881C10.8315 13.1042 11.0153 12.9813 11.1701 12.8263L15.8868 5.75131L8.8118 10.468C8.65684 10.6228 8.53391 10.8066 8.45003 11.0089C8.36616 11.2112 8.32299 11.4281 8.32299 11.6471C8.32299 11.8662 8.36616 12.083 8.45003 12.2854C8.53391 12.4877 8.65684 12.6715 8.8118 12.8263Z"
                                                fill="#ffffff"
                                            />
                                        </svg>
                                        <span>
                                            Score: <b>{evalScore[2]}</b>
                                        </span>
                                    </span>
                                    <div>
                                        This metric assesses how closely the context (top chunks) retrieved from the corpus aligns with the input question. A
                                        higher score reflects a greater relevance between the provided question and the retrieved context, indicating that the
                                        system has successfully identified the most pertinent information from the corpus to address the query.
                                    </div>
                                </div>
                                <div className={styles.scoreType}>
                                    <span>Answer Relevancy Score</span>
                                    <span>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="20" viewBox="0 0 20 20" fill="none">
                                            <path
                                                d="M16.9701 7.12631L15.9451 8.66797C16.4394 9.65387 16.6814 10.747 16.6495 11.8494C16.6175 12.9518 16.3125 14.0291 15.7618 14.9846H4.2118C3.4961 13.7431 3.19954 12.3039 3.36608 10.8805C3.53262 9.45715 4.15339 8.12533 5.13636 7.08249C6.11934 6.03966 7.41219 5.34134 8.82325 5.09105C10.2343 4.84076 11.6885 5.05183 12.9701 5.69297L14.5118 4.66797C12.9422 3.66149 11.0804 3.21048 9.2242 3.38709C7.36801 3.5637 5.62467 4.35772 4.27304 5.64215C2.92141 6.92658 2.0396 8.6272 1.76865 10.472C1.49769 12.3168 1.85326 14.1991 2.77846 15.818C2.92389 16.0699 3.1327 16.2793 3.38416 16.4255C3.63561 16.5717 3.92094 16.6495 4.2118 16.6513H15.7535C16.0471 16.6525 16.3359 16.576 16.5906 16.4297C16.8452 16.2833 17.0566 16.0723 17.2035 15.818C17.9713 14.4879 18.3566 12.9715 18.3169 11.4363C18.2772 9.901 17.814 8.40657 16.9785 7.11797L16.9701 7.12631Z"
                                                fill="#ffffff"
                                            />
                                            <path
                                                d="M8.8118 12.8263C8.96659 12.9813 9.1504 13.1042 9.35273 13.1881C9.55506 13.2719 9.77194 13.3151 9.99096 13.3151C10.21 13.3151 10.4269 13.2719 10.6292 13.1881C10.8315 13.1042 11.0153 12.9813 11.1701 12.8263L15.8868 5.75131L8.8118 10.468C8.65684 10.6228 8.53391 10.8066 8.45003 11.0089C8.36616 11.2112 8.32299 11.4281 8.32299 11.6471C8.32299 11.8662 8.36616 12.083 8.45003 12.2854C8.53391 12.4877 8.65684 12.6715 8.8118 12.8263Z"
                                                fill="#ffffff"
                                            />
                                        </svg>
                                        <span>
                                            Score: <b>{evalScore[1]}</b>
                                        </span>
                                    </span>
                                    <div>
                                        This score evaluates the relevance of the response generated by the system in relation to the original question posed. A
                                        higher score signifies that the generated answer is more directly related to the question, demonstrating the system's
                                        ability to produce pertinent and appropriate responses.
                                    </div>
                                </div>
                                <div className={styles.scoreType}>
                                    <span>Faithfulness Score</span>
                                    <span>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="20" viewBox="0 0 20 20" fill="none">
                                            <path
                                                d="M16.9701 7.12631L15.9451 8.66797C16.4394 9.65387 16.6814 10.747 16.6495 11.8494C16.6175 12.9518 16.3125 14.0291 15.7618 14.9846H4.2118C3.4961 13.7431 3.19954 12.3039 3.36608 10.8805C3.53262 9.45715 4.15339 8.12533 5.13636 7.08249C6.11934 6.03966 7.41219 5.34134 8.82325 5.09105C10.2343 4.84076 11.6885 5.05183 12.9701 5.69297L14.5118 4.66797C12.9422 3.66149 11.0804 3.21048 9.2242 3.38709C7.36801 3.5637 5.62467 4.35772 4.27304 5.64215C2.92141 6.92658 2.0396 8.6272 1.76865 10.472C1.49769 12.3168 1.85326 14.1991 2.77846 15.818C2.92389 16.0699 3.1327 16.2793 3.38416 16.4255C3.63561 16.5717 3.92094 16.6495 4.2118 16.6513H15.7535C16.0471 16.6525 16.3359 16.576 16.5906 16.4297C16.8452 16.2833 17.0566 16.0723 17.2035 15.818C17.9713 14.4879 18.3566 12.9715 18.3169 11.4363C18.2772 9.901 17.814 8.40657 16.9785 7.11797L16.9701 7.12631Z"
                                                fill="#ffffff"
                                            />
                                            <path
                                                d="M8.8118 12.8263C8.96659 12.9813 9.1504 13.1042 9.35273 13.1881C9.55506 13.2719 9.77194 13.3151 9.99096 13.3151C10.21 13.3151 10.4269 13.2719 10.6292 13.1881C10.8315 13.1042 11.0153 12.9813 11.1701 12.8263L15.8868 5.75131L8.8118 10.468C8.65684 10.6228 8.53391 10.8066 8.45003 11.0089C8.36616 11.2112 8.32299 11.4281 8.32299 11.6471C8.32299 11.8662 8.36616 12.083 8.45003 12.2854C8.53391 12.4877 8.65684 12.6715 8.8118 12.8263Z"
                                                fill="#ffffff"
                                            />
                                        </svg>
                                        <span>
                                            Score: <b>{evalScore[0]}</b>
                                        </span>
                                    </span>
                                    <div>
                                        The faithfulness score is a measure of accuracy, determining how well the generated response from the system adheres to
                                        the factual content within the retrieved context (top chunks). A higher score indicates that the response is not only
                                        relevant but also maintains fidelity to the facts presented in the context, ensuring reliability in the system's output.
                                    </div>
                                </div>
                            </div>
                        </Typography>
                    </Box>
                </Modal>
            </div>
             
        </div> 
    );
};

export default Chat;





