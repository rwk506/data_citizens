import { useRef, useState, useEffect, useLayoutEffect } from "react";
import {} from "@fluentui/react";
import { GlobeFilled, BuildingMultipleFilled, AddFilled, ChatSparkleFilled } from "@fluentui/react-icons";
import { ITag } from "@fluentui/react/lib/Pickers";
import {
    Toggle,
    Label,
    Checkbox,
    Panel,
    DefaultButton,
    TextField,
    SpinButton,
    Separator,
    ComboBox,
    IComboBox,
    IComboBoxOption,
    TooltipHost,
    ITooltipHostStyles,
    mergeStyles
} from "@fluentui/react";

import rlbgstyles from "../../components/ResponseLengthButtonGroup/ResponseLengthButtonGroup.module.css";
import rtbgstyles from "../../components/ResponseTempButtonGroup/ResponseTempButtonGroup.module.css";
import Button from "@mui/material/Button";
import { AppConstants } from "../../utilities/utils";
import { Navbar } from 'react-chat-elements';
import {
    chatApiV2,
    Approaches,
    ChatResponse,
    ChatTurn,
    ChatMode,
    ChatRequestV2,
    chatHistoryapi,
    deleteChatThread,
    getRagScores,
    logoutFromApplication
} from "../../api";
import { Answer, AnswerError } from "../../components/Answer";
import { QuestionInput } from "../../components/QuestionInput";
import { ExampleList } from "../../components/Example";
import { UserChatMessage } from "../../components/UserChatMessage";
import { AnalysisPanelV2, AnalysisPanelTabs } from "../../components/AnalysisPanel";
import { SettingsButton } from "../../components/SettingsButton";
import { InfoButton } from "../../components/InfoButton";
import { ClearChatButton } from "../../components/ClearChatButton";
import { ResponseLengthButtonGroup } from "../../components/ResponseLengthButtonGroup";
import { ResponseTempButtonGroup } from "../../components/ResponseTempButtonGroup";
/* import { ChatModeButtonGroup } from "../../components/ChatModeButtonGroup";
 */ import { InfoContent } from "../../components/InfoContent/InfoContent";
import { FolderPicker, FolderPickerNested } from "../../components/FolderPicker";
import { TagPickerInline } from "../../components/TagPicker";
import React from "react";
import { Info16Regular, History24Regular, Home24Regular , New24Regular, HandDraw24Regular, PersonHome24Regular, ArchiveSettings24Regular} from "@fluentui/react-icons";
import CircularProgress from "@mui/material/CircularProgress";
import Backdrop from "@mui/material/Backdrop";

import Accordion from "@mui/material/Accordion";
import AccordionSummary from "@mui/material/AccordionSummary";
import AccordionDetails from "@mui/material/AccordionDetails";
import { NavLink } from "react-router-dom";
import Modal from "@mui/material/Modal";
import Box from "@mui/material/Box";
import { FileDropdown } from "../../components/FileDropdown";
import useMobileScreen from "./useMobileScreen";
import { ChatHistory } from "../../components/ChatHistory/ChatHistory";
import Typography from "@mui/material/Typography";
import { AddSquare24Regular } from "@fluentui/react-icons";

import {
    AppItem,
    Hamburger,
    NavCategory,
    NavCategoryItem,
    NavDivider,
    NavDrawer,
    NavDrawerBody,
    NavDrawerHeader,
    NavDrawerProps,
    NavItem,
    NavItemValue,
    NavSectionHeader,
    NavSubItem,
    NavSubItemGroup,
    OnNavItemSelectData,
  } from "@fluentui/react-nav-preview";
  import {
 
    Switch,
    Tooltip,
    makeStyles,
    tokens,
    useId,
  } from "@fluentui/react-components";
  import {
    Board20Filled,
    Board20Regular,
    BoxMultiple20Filled,
    BoxMultiple20Regular,
    DataArea20Filled,
    DataArea20Regular,
    DocumentBulletListMultiple20Filled,
    DocumentBulletListMultiple20Regular,
    HeartPulse20Filled,
    HeartPulse20Regular,
    MegaphoneLoud20Filled,
    MegaphoneLoud20Regular,
    NotePin20Filled,
    NotePin20Regular,
    People20Filled,
    People20Regular,
    PeopleStar20Filled,
    PeopleStar20Regular,
    Person20Filled,
    PersonLightbulb20Filled,
    PersonLightbulb20Regular,
    Person20Regular,
    PersonSearch20Filled,
    PersonSearch20Regular,
    PreviewLink20Filled,
    PreviewLink20Regular,
    bundleIcon,
    PersonCircle32Regular,
  } from "@fluentui/react-icons";
  
  const useStyles = makeStyles({
    root: {
      overflow: "hidden",
      display: "flex",
      height: "700px",
      margin:"4% 1% 1% 1%"
      
    },
    content: {
      flex: "1",
      padding: "16px",
      display: "grid",
      justifyContent: "flex-start",
      alignItems: "flex-start",
        
    },
    field: {
      display: "flex",
      marginTop: "4px",
      marginLeft: "8px",
      flexDirection: "column",
      gridRowGap: tokens.spacingVerticalS,
       
    },
  });
  
  const Person = bundleIcon(Person20Filled, Person20Regular);
  const Dashboard = bundleIcon(Board20Filled, Board20Regular);
  const Announcements = bundleIcon(MegaphoneLoud20Filled, MegaphoneLoud20Regular);
  const EmployeeSpotlight = bundleIcon(
    PersonLightbulb20Filled,
    PersonLightbulb20Regular
  );
  const Search = bundleIcon(PersonSearch20Filled, PersonSearch20Regular);
  const PerformanceReviews = bundleIcon(
    PreviewLink20Filled,
    PreviewLink20Regular
  );
  const JobPostings = bundleIcon(NotePin20Filled, NotePin20Regular);
  const Interviews = bundleIcon(People20Filled, People20Regular);
  const HealthPlans = bundleIcon(HeartPulse20Filled, HeartPulse20Regular);
  const TrainingPrograms = bundleIcon(BoxMultiple20Filled, BoxMultiple20Regular);
  const CareerDevelopment = bundleIcon(PeopleStar20Filled, PeopleStar20Regular);
  const Analytics = bundleIcon(DataArea20Filled, DataArea20Regular);
  const Reports = bundleIcon(
    DocumentBulletListMultiple20Filled,
    DocumentBulletListMultiple20Regular
  );
  
  // A type that represents a navItemValue and its potential children.
  // An empty children array indicates a Single top level NavItem.
  // A hydrated children array indicates a NavCategoryItem with children.
  type NavItemValueCombo = { parent: string; children: string[] };
  
  // This is a list of navItemValues and their potential children
  // Ite exactly matches the NavDrawer in the story below
  // This is how a consumer might store them in their app
  const navItemValueList: NavItemValueCombo[] = [
    { parent: "1", children: [] },
    { parent: "2", children: [] },
    { parent: "3", children: [] },
    { parent: "4", children: [] },
    { parent: "5", children: [] },
    { parent: "6", children: ["7", "8"] },
    { parent: "9", children: [] },
    { parent: "10", children: [] },
    { parent: "11", children: ["12", "13"] },
    { parent: "14", children: [] },
    { parent: "15", children: [] },
    { parent: "16", children: ["17", "18"] },
    { parent: "19", children: [] },
    { parent: "20", children: [] },
  ];
  
  type SelectedPage = {
    newSelectedCategory: string | undefined;
    newSelectedValue: string;
  };
  
  const getRandomPage = (): SelectedPage => {
    const randomIndex = Math.floor(Math.random() * navItemValueList.length);
    const randomItem = navItemValueList[randomIndex];
  
    // there are no children, so we're selecting a top level item
    if (randomItem.children.length === 0) {
      return {
        newSelectedCategory: undefined,
        newSelectedValue: randomItem.parent,
      };
    } else {
      // there are children, so we're including a category and it's child as the selectedValue
      const randomChildIndex = Math.floor(
        Math.random() * randomItem.children.length
      );
      return {
        newSelectedCategory: randomItem.parent,
        newSelectedValue: randomItem.children[randomChildIndex],
      };
    }
  };
  
 
interface User {
    message: string;
    onEditSubmit: (msg: any) => void;
    envConfig: any;
}
interface Props {
    envConfig?: any;
    userDetails?: any;
}



const Chat = ({ envConfig, userDetails = {} }: Props) => {
    const [isConfigPanelOpen, setIsConfigPanelOpen] = useState(false);
    const [isInfoPanelOpen, setIsInfoPanelOpen] = useState(false);
    const [retrieveCount, setRetrieveCount] = useState<number>(envConfig?.document_retriever_count || 5);
    const [useSuggestFollowupQuestions, setUseSuggestFollowupQuestions] = useState<boolean>(true);
    const [userPersona, setUserPersona] = useState<string>("analyst");
    const [systemPersona, setSystemPersona] = useState<string>("an Assistant");
    const [promptTemplate, setPromptTemplate] = useState<string>("");
    const [excludeCategory, setExcludeCategory] = useState<string>("");
    const [useSemanticRanker, setUseSemanticRanker] = useState<boolean>(false);
    const [useEnrichedEmbeddings, setUseEnrichEmbeddings] = useState<boolean>(false);
    const [useMultiVectorQuery, setMultivectorQuery] = useState<boolean>(false);
    const [aiPersona, setAiPersona] = useState<string>("");
    const [useSemanticCaptions, setUseSemanticCaptions] = useState<boolean>(false);

    // Setting responseLength to 2048 by default, this will effect the default display of the ResponseLengthButtonGroup below.
    // It must match a valid value of one of the buttons in the ResponseLengthButtonGroup.tsx file.
    // If you update the default value here, you must also update the default value in the onResponseLengthChange method.
    const [responseLength, setResponseLength] = useState<number>(1024);
    // Setting responseTemp to 0.6 by default, this will effect the default display of the ResponseTempButtonGroup below.
    // It must match a valid value of one of the buttons in the ResponseTempButtonGroup.tsx file.
    // If you update the default value here, you must also update the default value in the onResponseTempChange method.
    const [responseTemp, setResponseTemp] = useState<number>(0.6);

    const [activeChatMode, setChatMode] = useState<ChatMode>(ChatMode.WorkOnly);
    const [defaultApproach, setDefaultApproach] = useState<string>(Approaches.ReadRetrieveRead);
    const [activeApproach, setActiveApproach] = useState<string>(Approaches.ReadRetrieveRead);
    /*     const [featureFlags, setFeatureFlags] = useState<GetFeatureFlagsResponse | undefined>(undefined);
     */
    const lastQuestionRef = useRef<string>("");
    const lastQuestionWorkCitationRef = useRef<{ [key: string]: { citation: string; source_path: string; page_number: string } }>({});
    const lastQuestionWebCitiationRef = useRef<{ [key: string]: { citation: string; source_path: string; page_number: string } }>({});
    const lastQuestionThoughtChainRef = useRef<{ [key: string]: string }>({});
    const chatMessageStreamEnd = useRef<HTMLDivElement | null>(null);
    const [isChatHistoryOpen, setIsChatHistoryPanelOpen] = useState(false);
    const [history, setChatHistory] = useState<any[]>([]);
    const [isChatHistoryLoaded, setChatHistoryLoaded] = useState<boolean>(false);
    const [adjustPanelModal, setAdjustPanelModal] = useState(false);
    const handleCloseAdjustPanelModal = () => setAdjustPanelModal(false);
    const [evalScore, setEvalScore] = useState<any>([]);

    const [activeCitation, setActiveCitation] = useState<string>();
    const [activeCitationSourceFile, setActiveCitationSourceFile] = useState<string>();
    const [activeCitationSourceFilePageNumber, setActiveCitationSourceFilePageNumber] = useState<string>();
    const [activeAnalysisPanelTab, setActiveAnalysisPanelTab] = useState<AnalysisPanelTabs | undefined>(undefined);
    const [selectedFolders, setSelectedFolders] = useState<string[]>([]);
    const [selectedTags, setSelectedTags] = useState<ITag[]>([]);

    const [selectedAnswer, setSelectedAnswer] = useState<number>(0);
    const [answers, setAnswers] = useState<[user: string, response: ChatResponse][]>([]);
    const [answerStream, setAnswerStream] = useState<ReadableStream | undefined>(undefined);
    const [abortController, setAbortController] = useState<AbortController | undefined>(undefined);

    const [open, setOpen] = useState(false);
    const handleClose = () => setOpen(false);
    const [analysisPanelModal, setAnalysisPanelModal] = useState(false);
    const handleCloseAnalysisPanelModal = () => setAnalysisPanelModal(false);
    const isMobile = useMobileScreen();
    const [modelName, setModelName] = useState<any>();

    const [selectedFiles, setSelectedFiles] = useState<string[]>([]);
    const [retriverFeature, setRetriverFeature] = useState<any>();
    const [queryTransformationKey, setQueryTransformationKey] = useState<any>();
    const [sourceDateKey, setSourceDateKey] = useState<any>();
    const [chatHistoryIndex, setChatHistoryIndex] = useState();
    const [conversationId, setConversationId] = useState<string>();

    const [retriverTooltip, setRetriverTooltip] = useState(
        "Combined full text with semantic vector search for a comprehensive retrieval. Optimal for most and for a balanced precision & recall."
    );
    const [queryTooltip, setQueryTooltip] = useState(
        "Creates a search query based on conversation history and the new question. Optimal for enhanced retrieval."
    );

    const hostStyles: Partial<ITooltipHostStyles> = { root: { display: "inline-block" } };
    const [enableCompositeScore, setEnableCompositeScore] = useState<boolean>(false);
    const [ragData, setRagData] = useState<any>([]);
    const [scoreData, getRagData] = useState<any>([]);
    const [isRagPanelOpen, setIsRagPanelOpen] = useState(false);
    const [isAnalysisPanelOpen, setIsAnalysisPanelOpen] = useState<boolean>(false);

    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [error, setError] = useState<unknown>();
    const [loader, setLoader] = useState<boolean>(false);
    const [answerLoadedForHistory, setAnswerLoadedForHistory] = useState(false);
  const [isNavOpen, setIsNavOpen] = React.useState(true);

    async function fetchFeatureFlags() {
        try {
            //  const fetchedFeatureFlags = await getFeatureFlags();
            // setFeatureFlags(fetchedFeatureFlags);
        } catch (error) {
            // Handle the error here
            console.log(error);
        }
    }
    const chat_input_ref = useRef(null);
    useEffect(() => {
        if (envConfig?.document_retriever_count !== undefined) {
            setRetrieveCount(envConfig.document_retriever_count);
        }
    }, [envConfig?.document_retriever_count]);

    const getUserId = (): string => {
        return  AppConstants.userId;
    };
    const getIpAddress = (): string => {
        return   "";
    };
    const makeApiRequest = async (
        question: string,
        approach: Approaches,
        work_citation_lookup: { [key: string]: { citation: string; source_path: string; page_number: string } },
        web_citation_lookup: { [key: string]: { citation: string; source_path: string; page_number: string } },
        thought_chain: { [key: string]: string }
    ) => {
        lastQuestionRef.current = question;
        lastQuestionWorkCitationRef.current = work_citation_lookup;
        lastQuestionWebCitiationRef.current = web_citation_lookup;
        lastQuestionThoughtChainRef.current = thought_chain;
        setActiveApproach(approach);

        setAnswerLoadedForHistory(false);
        error && setError(undefined);
        setIsLoading(true);
        setActiveCitation(undefined);
        setActiveAnalysisPanelTab(undefined);

        try {
            const history: ChatTurn[] = answers.map(a => ({ user: a[0], bot: a[1].answer }));
            const request: ChatRequestV2 = {
                history: [...history, { user: question, bot: undefined }],
                approach: approach,
             
                citation_lookup: {},
                thought_chain: thought_chain,
                userId: getUserId(),
                ipAddress: getIpAddress(),
                conversationId: conversationId
            };

            const temp: ChatResponse = {
                answer: "",
                thoughts: "",
                data_points: [],
                approach: approach,
                thought_chain: {
                    work_response: "",
                    web_response: ""
                },
                work_citation_lookup: {},
                web_citation_lookup: {},
                citation_lookup: {},
                conversation_id: "",
                message_id: "",
                latency: "",
                model: "",
                usage: { total_tokens: 0 }, //TODO
                feedback_type: "",
                scores: {}
            };

            setAnswers([...answers, [question, temp]]);
            const controller = new AbortController();
            setAbortController(controller);
            const signal = controller.signal;
            const result = await chatApiV2(request, signal);
            if (!result.body) {
                throw Error("No response body");
            }
            setAnswerStream(result.body);
        } catch (e) {
            setStreamIsProcessed();
            setError(e);
        }
    };
    /**
     * function identify the Stream is ready
     * @param status
     */
    const setStreamReady = () => {
        //setIsLoading(false);
        chatMessageStreamEnd.current?.scrollIntoView({ behavior: "smooth", block: "end", inline: "nearest" });
    };
    /**
     * function identify the Stream is Processed
     * @param status
     */
    const setStreamIsProcessed = () => {
        setIsLoading(false);
        chatMessageStreamEnd.current?.scrollIntoView({ behavior: "smooth", block: "end", inline: "nearest" });
    };

    const clearChat = () => {
        lastQuestionRef.current = "";
        lastQuestionWorkCitationRef.current = {};
        lastQuestionWebCitiationRef.current = {};
        lastQuestionThoughtChainRef.current = {};
        error && setError(undefined);
        setActiveCitation(undefined);
        setActiveAnalysisPanelTab(undefined);
        setAnswers([]);
        setConversationId(undefined);
        setIsChatHistoryPanelOpen(false);
        setChatHistoryIndex(undefined);
        setIsAtBottom(true);
    };

    const chatHistory = async () => {
        setChatHistoryLoaded(true);
        const history: any = await chatHistoryapi("", getUserId());
        const data = history.history.conversation || [];
        setChatHistory(data);
        setChatHistoryLoaded(false);
    };

    const onResponseLengthChange = (_ev: any) => {
        for (let node of _ev.target.parentNode.childNodes) {
            if (node.value == _ev.target.value) {
                switch (node.value) {
                    case "1024":
                        node.className = `${rlbgstyles.buttonleftactive}`;
                        break;
                    case "2048":
                        node.className = `${rlbgstyles.buttonmiddleactive}`;
                        break;
                    case "3072":
                        node.className = `${rlbgstyles.buttonrightactive}`;
                        break;
                    default:
                        //do nothing
                        break;
                }
            } else {
                switch (node.value) {
                    case "1024":
                        node.className = `${rlbgstyles.buttonleft}`;
                        break;
                    case "2048":
                        node.className = `${rlbgstyles.buttonmiddle}`;
                        break;
                    case "3072":
                        node.className = `${rlbgstyles.buttonright}`;
                        break;
                    default:
                        //do nothing
                        break;
                }
            }
        }
        // the or value here needs to match the default value assigned to responseLength above.
        setResponseLength((_ev.target.value as number) || 2048);
    };

    const onResponseTempChange = (_ev: any) => {
        for (let node of _ev.target.parentNode.childNodes) {
            if (node.value == _ev.target.value) {
                switch (node.value) {
                    case "1.0":
                        node.className = `${rtbgstyles.buttonleftactive}`;
                        break;
                    case "0.6":
                        node.className = `${rtbgstyles.buttonmiddleactive}`;
                        break;
                    case "0":
                        node.className = `${rtbgstyles.buttonrightactive}`;
                        break;
                    default:
                        //do nothing
                        break;
                }
            } else {
                switch (node.value) {
                    case "1.0":
                        node.className = `${rtbgstyles.buttonleft}`;
                        break;
                    case "0.6":
                        node.className = `${rtbgstyles.buttonmiddle}`;
                        break;
                    case "0":
                        node.className = `${rtbgstyles.buttonright}`;
                        break;
                    default:
                        //do nothing
                        break;
                }
            }
        }
        // the or value here needs to match the default value assigned to responseLength above.
        setResponseTemp((_ev.target.value as number) || 0.6);
    };

    const onChatModeChange = (_ev: any) => {
        abortController?.abort();
        const chatMode = (_ev.target.value as ChatMode) || ChatMode.WorkOnly;
        setChatMode(chatMode);
        setDefaultApproach(Approaches.ReadRetrieveRead);
        setActiveApproach(Approaches.ReadRetrieveRead);
        clearChat();
    };

    const handleToggle = () => {
        defaultApproach == Approaches.ReadRetrieveRead;
    };

    useEffect(() => {
        fetchFeatureFlags();
    }, []);
    useEffect(() => {
        chatMessageStreamEnd.current?.scrollIntoView({ behavior: "smooth" });
    }, [isLoading]);

    const onRetrieveCountChange = (_ev?: React.SyntheticEvent<HTMLElement, Event>, newValue?: string) => {
        setRetrieveCount(parseInt(newValue || "5"));
    };

    const onUserPersonaChange = (_ev?: React.FormEvent<HTMLInputElement | HTMLTextAreaElement>, newValue?: string) => {
        setUserPersona(newValue || "");
    };

    const onSystemPersonaChange = (_ev?: React.FormEvent<HTMLInputElement | HTMLTextAreaElement>, newValue?: string) => {
        setSystemPersona(newValue || "");
    };

    const onUseSuggestFollowupQuestionsChange = (_ev?: React.FormEvent<HTMLElement | HTMLInputElement>, checked?: boolean) => {
        setUseSuggestFollowupQuestions(!!checked);
    };

    const onExampleClicked = (example: string) => {
        makeApiRequest(example, Approaches.ReadRetrieveRead, {}, {}, {});
    };

    const onShowCitation = (citation: string, citationSourceFile: string, citationSourceFilePageNumber: string, index: number) => {
        setAnalysisPanelModal(true); //T TODO
        setIsAnalysisPanelOpen(true); //T TODO

        if (activeCitation === citation && activeAnalysisPanelTab === AnalysisPanelTabs.CitationTab && selectedAnswer === index) {
            setActiveAnalysisPanelTab(undefined);
        } else {
            setActiveCitation(citation);
            setActiveCitationSourceFile(citationSourceFile);
            setActiveCitationSourceFilePageNumber(citationSourceFilePageNumber);
            setActiveAnalysisPanelTab(AnalysisPanelTabs.CitationTab);
        }
        setIsChatHistoryPanelOpen(false);
        setSelectedAnswer(index);
    };

    const onToggleTab = (tab: AnalysisPanelTabs, index: number) => {
        setAnalysisPanelModal(true); //T TODO
        setIsAnalysisPanelOpen(true); //T TODO
        if (activeAnalysisPanelTab === tab && selectedAnswer === index) {
            setActiveAnalysisPanelTab(undefined);
        } else {
            setActiveAnalysisPanelTab(tab);
        }
        setIsChatHistoryPanelOpen(false);
        setSelectedAnswer(index);
    };

    const onSelectedKeyChanged = (selectedFolders: string[]) => {
        setSelectedFolders(selectedFolders);
    };

    const onSelectedTagsChange = (selectedTags: ITag[]) => {
        setSelectedTags(selectedTags);
    };

    useEffect(() => {
        // Hide Scrollbar for this page
        document.body.classList.add("chat-overflow-hidden-body");
        // Do not apply to other pages
        return () => {
            document.body.classList.remove("chat-overflow-hidden-body");
        };
    }, []);

    const updateAnswerAtIndex = (index: number, response: ChatResponse) => {

      
        setAnswers(currentAnswers => {

           
            const updatedAnswers = [...currentAnswers];
            updatedAnswers[index] = [updatedAnswers[index][0], response];
            return updatedAnswers;
        });
        setConversationId(response?.conversation_id);
    };

    const removeAnswerAtIndex = (index: number) => {
        const newItems = answers.filter((item, idx) => idx !== index);
        setAnswers(newItems);
    };

    const onSelectedFileChanged = (selectedFiles: string[]) => {
        setSelectedFiles(selectedFiles);
    };

    const customCheckboxStyles = mergeStyles({
        selectors: {
            "& .ms-Checkbox-checkbox": {
                borderColor: `${envConfig?.application_theme_color}!important`
            },
            "& .ms-Checkbox.is-checked .ms-Checkbox-checkbox": {
                borderColor: `${envConfig?.application_theme_color} !important`,
                backgroundColor: `${envConfig?.application_theme_color} !important`
            },
            "& .ms-Checkbox.is-checked .ms-Checkbox-checkmark": {
                color: "white !important"
            },
            "& .ms-Checkbox-checkbox:hover": {
                borderColor: `${envConfig?.application_theme_color} !important`
            },
            "& .ms-Checkbox-checkbox:hover .ms-Checkbox-checkmark": {
                color: "white !important"
            }
        }
    });

    const onModelNameChange = (event: React.FormEvent<IComboBox>, option?: IComboBoxOption): void => {
        setModelName(option);
    };

    const onQueryTransformationChange = (event: React.FormEvent<IComboBox>, option?: IComboBoxOption): void => {
        setQueryTransformationKey(option);
        const tooltipInfo: any = {
            normalized: "Creates a search query based on conversation history and the new question. Optimal for enhanced retrieval.",
            sub_query:
                "Breaks down the main query into smaller parts. Intermediate responses from each combined into a final answer. Optimal for generation from multiple retrieved documents.",
            hyde: "Creates a theoretical document to answer the query, instead of from the search index. Optimal for creative and open ended questions."
        };
        const key = option?.key || "";
        setQueryTooltip(tooltipInfo[key]);
    };

    const onSourceDateChange = (event: React.FormEvent<IComboBox>, option?: IComboBoxOption): void => {
        setSourceDateKey(option);
    };

    const onRetriverFeatureChange = (event: React.FormEvent<IComboBox>, option?: IComboBoxOption): void => {
        setRetriverFeature(option);
        const tooltipInfo: any = {
            default: "Combined full text with semantic vector search for a comprehensive retrieval. Optimal for most and for a balanced precision & recall.",
            multi_vector_query: "Sends multiple queries targeting multiple vector fields to improve retrieval accuracy. Optimal for complex, nuanced queries."
        };
        const key = option?.key || "";
        setRetriverTooltip(tooltipInfo[key]);
    };

    const onEnableCompositeScore = (_ev?: React.FormEvent<HTMLElement | HTMLInputElement>, checked?: boolean) => {
        setEnableCompositeScore(!!checked);
    };
    const [isAtBottom, setIsAtBottom] = useState<boolean>(true);
    const chatMessageStreamRef = useRef<HTMLDivElement>(null);
    const checkScrollPosition = () => {
        if (!chatMessageStreamRef.current) return;

        const threshold = 10;
        const isUserAtBottom =
            chatMessageStreamRef.current.scrollHeight - chatMessageStreamRef.current.scrollTop <= chatMessageStreamRef.current.clientHeight + threshold;

        setIsAtBottom(isUserAtBottom);
    };

    const handleScroll = () => {
        checkScrollPosition();
    };

    const selectedConversationThread = async (conversationThread: any) => {
        if (isAnalysisPanelOpen) {
            // T TODO
            setActiveAnalysisPanelTab(undefined);
            setIsAnalysisPanelOpen(false);
        }

        setLoader(true);
        const history: any = await chatHistoryapi(conversationThread[0]);

        const msg = history.history.conversation[0].messages.map((e: any) => {
            if (e.role == "user") {
                return e.answer;
            } else {
                return {
                    answer: e.answer,
                    citation_lookup: e.citation_lookup,
                    data_points: e.data_points,
                    thoughts: e.thoughts,
                    scores: e.scores,
                    usage: e.usage,
                    latency: e.latency,
                    conversation_id: e.conversation_id,
                    message_id: e.message_id,
                    feedback_type: e.feedback_type,
                    model: e.model,
                    approach: "rrr"
                };
            }
        });

        const threadData = msg.reduce((acc: any[], curr: any, i: number) => {
            if (!(i % 2)) {
                acc.push(msg.slice(i, i + 2));
            }
            return acc;
        }, []);
        setAnswers(threadData);
        setConversationId(conversationThread[0]);
        setLoader(false);

        setAnswerLoadedForHistory(true);

        lastQuestionRef.current = " ";
        setTimeout(() => {
            checkScrollPosition();
        }, 100);
    };

    const deleteConversationThread = async (e: any, id: any) => {
        e.stopPropagation();
        e.nativeEvent.stopImmediatePropagation();
        await deleteChatThread(id);
        const data = history.filter(function (d: { id: any }) {
            return d.id != id;
        });

        setChatHistory(data);
        lastQuestionRef.current = "";
        error && setError(undefined);
        setActiveCitation(undefined);
        setActiveAnalysisPanelTab(undefined);
        setAnswers([]);
        setConversationId(undefined);
    };

    const onShowCompositeScore = (a: any, b: any, c: any) => {
        setOpen(true);
        setEvalScore([a, b, c]);
    };

    const ragEvaluationScore = () => {
        setIsRagPanelOpen(!isRagPanelOpen);

        const filteredData = scoreData?.filter((i: any) => {
            const retriverFeatureName: any = retriverFeature ? retriverFeature.key : "default";
            const queryTransformationName: any = queryTransformationKey ? queryTransformationKey.key : "simple";

            if (
                i.n_retriever_results == retrieveCount &&
                i.retriever_feature == retriverFeatureName &&
                i.query_transformation_type == queryTransformationName &&
                i.use_semantic_reranking == useSemanticRanker
            )
                return i;
        });
        setRagData([...filteredData, scoreData[0]]);
    };
    useEffect(() => {
        const chatMessageStream = chatMessageStreamRef.current;
        if (chatMessageStream) {
            chatMessageStream.addEventListener("scroll", handleScroll, { passive: true });
        }

        return () => {
            if (chatMessageStream) {
                chatMessageStream.removeEventListener("scroll", handleScroll);
            }
        };
    }, [answers]);

    const scrollToBottom = () => {
        if (chatMessageStreamRef.current) {
            chatMessageStreamRef.current.scrollTop = chatMessageStreamRef.current.scrollHeight;
        }
    }; 
    async function fetchRagScores() {
        try {
            const v = await getRagScores();
            if (!v) {
                return null;
            }
            getRagData(v.response);
        } catch (error) {
            // Handle the error here
            console.log(error);
        }
    }

   

    useEffect(() => {
        if (envConfig?.advanced_settings[0]?.show_rag_eval_score) {
            fetchRagScores();
        }
    }, []);

    const onSemanticRankerChange = (_ev?: React.FormEvent<HTMLElement | HTMLInputElement>, checked?: boolean) => {
        setUseSemanticRanker(!!checked);
    };


    
 const styles = useStyles();

 const multipleLabelId = useId("multiple-label");

 const [openCategories, setOpenCategories] = React.useState<NavItemValue[]>([
   "6",
   "11",
 ]);
 const [selectedCategoryValue, setSelectedCategoryValue] = React.useState<string|undefined >("6");
 const [selectedValue, setSelectedValue] = React.useState<string>("7");
 const [isMultiple, setIsMultiple] = React.useState(true);

 const handleCategoryToggle = (
   ev: Event | React.SyntheticEvent<Element, Event>,
   data: OnNavItemSelectData
 ) => {
   if (data.value === undefined && data.categoryValue) {
     // we're just opening it,
     setOpenCategories([data.categoryValue as string]);
   }

   if (isMultiple) {
     // if it's already open, remove it from the list
     if (openCategories.includes(data.categoryValue as string)) {
       setOpenCategories([
         ...openCategories.filter(
           (category) => category !== data.categoryValue
         ),
       ]);
     } else {
       // otherwise add it
       setOpenCategories([...openCategories, data.categoryValue as string]);
     }
   } else {
     // if it's already open, remove it from the list
     if (openCategories.includes(data.categoryValue as string)) {
       setOpenCategories([]);
     } else {
       // otherwise add it
       setOpenCategories([data.categoryValue as string]);
     }
   }
 };

 const handleItemSelect = (
   ev: Event | React.SyntheticEvent<Element, Event>,
   data: OnNavItemSelectData
 ) => {
   setSelectedCategoryValue(data.categoryValue as string);
   setSelectedValue(data.value as string);
 };

 

 const handleNavigationClick = () => {
   const { newSelectedCategory, newSelectedValue } = getRandomPage();

   setSelectedCategoryValue(newSelectedCategory);
   setSelectedValue(newSelectedValue);
 };

 const handleMultipleChange = (
   ev: Event | React.SyntheticEvent<Element, Event>,
   data: { checked: boolean }
 ) => {
   setIsMultiple(data.checked);

   if (data.checked) {
     setOpenCategories(["6", "11"]);
   } else {
     setOpenCategories(["6"]);
   }
 };

 const renderHamburgerWithToolTip = () => {
    return (
      <Tooltip   relationship="label">
        <Hamburger onClick={() => setIsNavOpen(!isNavOpen)} />
      </Tooltip>
    );
  };

 
 
    return (
        <div className={styles.root}>
        <NavDrawer
          // This a controlled example,
          // so don't use these props
          // defaultSelectedValue="7"
          // defaultSelectedCategoryValue="6"
          // defaultOpenCategories={['6']}
          // multiple={isMultiple}
          onNavCategoryItemToggle={handleCategoryToggle}
          onNavItemSelect={handleItemSelect}
          openCategories={openCategories}
          selectedValue={selectedValue}
          selectedCategoryValue={selectedCategoryValue}
          type={"inline"}
          open={isNavOpen}
          
        >
        <NavDrawerHeader>{renderHamburgerWithToolTip()}</NavDrawerHeader>
        
          <NavDrawerBody>
          <AppItem
            icon={<PersonCircle32Regular />}
            as="a"
         
          >
            Test User
          </AppItem>
            <NavItem icon={<Home24Regular />} value="5"   style={{"padding": "10px 12px 10px 2px"}}>
                Home
            </NavItem>
            <NavItem icon={<AddSquare24Regular />} value="6"   style={{"padding": "10px 12px 10px 2px"}}>
                 New Chat
            </NavItem>
            <NavItem 
             onClick={() => {
                if (!isLoading) {
                    setIsChatHistoryPanelOpen(!isChatHistoryOpen);
                    chatHistory();
                }
            }}
            icon={<History24Regular />} value="1"   style={{"padding": "10px 12px 10px 2px"}}>
            Show history

            </NavItem> 
            <NavItem icon={<New24Regular />} value="2" style={{"padding": "10px 12px 10px 2px"}}>
             Grant Matching
            </NavItem>
            <NavItem href="#content"icon={<HandDraw24Regular />} value="3" style={{"padding": "10px 12px 10px 2px"}}>
                Upload data
            </NavItem>
            <NavItem href="#content"icon={<ArchiveSettings24Regular />} value="12" style={{"padding": "10px 12px 10px 2px"}}>
                Configuration
            </NavItem>
            <NavItem icon={<PersonHome24Regular />} value="4" style={{"padding": "10px 12px 10px 2px"}}>
            About Grant Guru
            </NavItem>

            <NavItem value="4" style={{"padding": "10px 12px 10px 2px"}}>          
            </NavItem>
            <NavItem value="4" style={{"padding": "10px 12px 10px 2px"}}>          
            </NavItem>
            <NavItem value="4" style={{"padding": "10px 12px 10px 2px"}}>          
            </NavItem>
            <NavItem value="4" style={{"padding": "10px 12px 10px 2px"}}>          
            </NavItem>
            <NavItem value="4" style={{"padding": "10px 12px 10px 2px"}}>          
            </NavItem>
            <NavItem value="4" style={{"padding": "10px 12px 10px 2px"}}>          
            </NavItem>
            <NavItem value="4" style={{"padding": "10px 12px 10px 2px"}}>          
            </NavItem>
            <NavItem value="4" style={{"padding": "10px 12px 10px 2px"}}>          
            </NavItem>
            {/* <NavItem icon={<PerformanceReviews />} value="5">
              Performance Reviews
            </NavItem>
            <NavSectionHeader>Employee Management</NavSectionHeader>
            <NavCategory value="6">
              <NavCategoryItem icon={<JobPostings />}>
                Job Postings
              </NavCategoryItem>
              <NavSubItemGroup>
                <NavSubItem value="7">Openings</NavSubItem>
                <NavSubItem value="8">Submissions</NavSubItem>
              </NavSubItemGroup>
            </NavCategory>
            <NavItem icon={<Interviews />} value="9">
              Interviews
            </NavItem>
  
            <NavSectionHeader>Benefits</NavSectionHeader>
            <NavItem icon={<HealthPlans />} value="10">
              Health Plans
            </NavItem>
            <NavCategory value="11">
              <NavCategoryItem icon={<Person />} value="12">
                Retirement
              </NavCategoryItem>
              <NavSubItemGroup>
                <NavSubItem value="13">Plan Information</NavSubItem>
                <NavSubItem value="14">Fund Performance</NavSubItem>
              </NavSubItemGroup>
            </NavCategory>
  
            <NavSectionHeader>Learning</NavSectionHeader>
            <NavItem icon={<TrainingPrograms />} value="15">
              Training Programs
            </NavItem>
            <NavCategory value="16">
              <NavCategoryItem icon={<CareerDevelopment />}>
                Career Development
              </NavCategoryItem>
              <NavSubItemGroup>
                <NavSubItem value="17">Career Paths</NavSubItem>
                <NavSubItem value="18">Planning</NavSubItem>
              </NavSubItemGroup>
            </NavCategory>
            <NavDivider />
            <NavItem target="_blank" icon={<Analytics />} value="19">
              Workforce Data
            </NavItem>
            <NavItem icon={<Reports />} value="20">
              Reports
            </NavItem> */}
          </NavDrawerBody>
        </NavDrawer>
       
            
            
                <div className={styles.chatContainer} id="entra" style={{"width":"100%", "overflow": "auto"}}>
                {!isNavOpen && renderHamburgerWithToolTip()}
                    {!lastQuestionRef.current ? (
                        <div className={styles.chatEmptyState}>
                            {/* <SparkleFilled fontSize={"120px"} primaryFill={"rgba(115, 118, 225, 1)"} aria-hidden="true" aria-label="Chat logo" /> */}
                            <span style={{"textAlign": "center"}}><h1 className={styles.chatEmptyStateTitle} style={{ color: envConfig?.application_theme_color }}>
                                {envConfig?.application_heading}
                            </h1> </span> 
                            <span className={styles.chatEmptyObjectives}>{envConfig?.subtitle}</span>
                            {/* <h2 className={styles.chatEmptyStateSubtitle}>Ask anything or try an example</h2> */}
                            <div style={{"height": "100px"}}> 
                                </div>
                             <ExampleList examples={envConfig?.questions} onExampleClicked={onExampleClicked} /> 
                        </div>
                    ) : (
                        <div className={styles.chatMessageStream} ref={chatMessageStreamRef} id="entra-1">
                            {loader && (
                                <Backdrop sx={{ color: "#fff", zIndex: 100 }} open={true}>
                                    <CircularProgress color="inherit" />
                                </Backdrop>
                            )}

                            {answers.map((answer, index) => (
                                <div key={index}>
                                    <UserChatMessage
                                        message={answer[0]}
                                        envConfig={envConfig}
                                        onEditSubmit={msg => makeApiRequest(msg, Approaches.ReadRetrieveRead, {}, {}, {})}
                                    />
                                    <div className={styles.chatMessageGpt}>
                                        <Answer
                                            key={index}
                                            answer={answer[1]}
                                            answerStream={answerStream}
                                            setError={error => {
                                                setError(error);
                                                removeAnswerAtIndex(index);
                                            }}
                                            setAnswer={response => updateAnswerAtIndex(index, response)}
                                            isSelected={selectedAnswer === index && activeAnalysisPanelTab !== undefined}
                                            onCitationClicked={(c, s, p) => onShowCitation(c, s, p, index)}
                                            onThoughtProcessClicked={() => onToggleTab(AnalysisPanelTabs.ThoughtProcessTab, index)}
                                            onCompositeScoreClicked={(a, b, c) => onShowCompositeScore(a, b, c)}
                                            onSupportingContentClicked={() => onToggleTab(AnalysisPanelTabs.SupportingContentTab, index)}
                                            onFollowupQuestionClicked={q =>
                                                makeApiRequest(
                                                    q,
                                                    answer[1].approach,
                                                    answer[1].work_citation_lookup,
                                                    answer[1].web_citation_lookup,
                                                    answer[1].thought_chain
                                                )
                                            }
                                            showFollowupQuestions={useSuggestFollowupQuestions}
                                            onAdjustClick={() => {
                                                setAdjustPanelModal(!adjustPanelModal);
                                                setIsConfigPanelOpen(!isConfigPanelOpen);
                                            }}
                                            onRegenerateClick={() =>
                                                makeApiRequest(
                                                    answers[index][0],
                                                    answer[1].approach,
                                                    answer[1].work_citation_lookup,
                                                    answer[1].web_citation_lookup,
                                                    answer[1].thought_chain
                                                )
                                            }
                                            updateFeedback={id => selectedConversationThread(id)}
                                            isStreamRequested={isLoading}
                                            setStreamReady={setStreamReady}
                                            setStreamIsProcessed={setStreamIsProcessed}
                                            envConfig={envConfig}
                                            answerLoadedForHistory={answerLoadedForHistory}
                                        />
                                    </div>
                                </div>
                            ))}
                            {error ? (
                                <>
                                    <UserChatMessage
                                        message={lastQuestionRef.current}
                                        envConfig={envConfig}
                                        onEditSubmit={msg => makeApiRequest(msg, Approaches.ReadRetrieveRead, {}, {}, {})}
                                    />
                                    <div className={styles.chatMessageGptMinWidth}>
                                        <AnswerError
                                            error={error.toString()}
                                            onRetry={() =>
                                                makeApiRequest(
                                                    lastQuestionRef.current,
                                                    Approaches.ReadRetrieveRead,
                                                    lastQuestionWorkCitationRef.current,
                                                    lastQuestionWebCitiationRef.current,
                                                    lastQuestionThoughtChainRef.current
                                                )
                                            }
                                        />
                                    </div>
                                </>
                            ) : null}
                            <div ref={chatMessageStreamEnd} />
                        </div>
                    )}

                    {!isAtBottom && (
                        <div onClick={scrollToBottom} className={styles.scrollToBottomButton}>
                            <svg width="15px" height="15px" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path
                                    fill-rule="evenodd"
                                    clip-rule="evenodd"
                                    d="M12 3C12.5523 3 13 3.44772 13 4V17.5858L18.2929 12.2929C18.6834 11.9024 19.3166 11.9024 19.7071 12.2929C20.0976 12.6834 20.0976 13.3166 19.7071 13.7071L12.7071 20.7071C12.3166 21.0976 11.6834 21.0976 11.2929 20.7071L4.29289 13.7071C3.90237 13.3166 3.90237 12.6834 4.29289 12.2929C4.68342 11.9024 5.31658 11.9024 5.70711 12.2929L11 17.5858V4C11 3.44772 11.4477 3 12 3Z"
                                    fill="#000000"
                                />
                            </svg>
                        </div>
                    )}
                    <div className={styles.chatInput}>
                        {activeChatMode == ChatMode.WorkPlusWeb && (
                            <div className={styles.chatInputWarningMessage}>
                                <div>
                                    Questions will be answered by default from Work
                                    <BuildingMultipleFilled fontSize={"20px"} primaryFill={"rgba(27, 74, 239, 1)"} aria-hidden="true" aria-label="Work Data" />
                                </div>
                            </div>
                        )}
                        <QuestionInput
                            clearOnSend
                            placeholder="How can we help you change the world today?"
                            disabled={isLoading}
                            onSend={question => makeApiRequest(question, Approaches.ReadRetrieveRead, {}, {}, {})}
                            onAdjustClick={() => setIsConfigPanelOpen(!isConfigPanelOpen)}
                            onInfoClick={() => setIsInfoPanelOpen(!isInfoPanelOpen)}
                            showClearChat={true}
                            onClearClick={clearChat}
                            ref={chat_input_ref}  
                            onRegenerateClick={() => makeApiRequest(lastQuestionRef.current, Approaches.ReadRetrieveRead, {}, {}, {})}
                        />
                    </div>
                </div>

                {answers.length > 0 && activeAnalysisPanelTab && isAnalysisPanelOpen && (
                    <>
                        {isMobile ? (
                            <Modal open={analysisPanelModal} onClose={handleCloseAnalysisPanelModal}>
                                <>
                                    <div className={styles.closeIcon}>
                                        <svg
                                            onClick={handleCloseAnalysisPanelModal}
                                            width="15"
                                            height="15"
                                            viewBox="0 0 26 26"
                                            fill="none"
                                            xmlns="http://www.w3.org/2000/svg"
                                        >
                                            <path
                                                d="M25.25 3.2175L22.7825 0.75L13 10.5325L3.2175 0.75L0.75 3.2175L10.5325 13L0.75 22.7825L3.2175 25.25L13 15.4675L22.7825 25.25L25.25 22.7825L15.4675 13L25.25 3.2175Z"
                                                fill="#343842"
                                            />
                                        </svg>
                                    </div>
                                    <AnalysisPanelV2
                                        className={styles.chatAnalysisPanel}
                                        activeCitation={activeCitation}
                                        sourceFile={activeCitationSourceFile}
                                        pageNumber={activeCitationSourceFilePageNumber}
                                        onActiveTabChanged={x => onToggleTab(x, selectedAnswer)}
                                        citationHeight="760px"
                                        answer={answers[selectedAnswer][1]}
                                        activeTab={activeAnalysisPanelTab}
                                    />
                                </>
                            </Modal>
                        ) : (
                            <div style={{ width: "50%" }}>
                                <AnalysisPanelV2
                                    className={styles.chatAnalysisPanel}
                                    activeCitation={activeCitation}
                                    sourceFile={activeCitationSourceFile}
                                    pageNumber={activeCitationSourceFilePageNumber}
                                    onActiveTabChanged={x => onToggleTab(x, selectedAnswer)}
                                    citationHeight="760px"
                                    answer={answers[selectedAnswer][1]}
                                    activeTab={activeAnalysisPanelTab}
                                />
                                <div
                                    className={styles.closeIcon}
                                    style={{ position: "absolute", top: "60px", right: "2%", cursor: "pointer", zIndex: 3 }}
                                    onClick={() => {
                                        setActiveAnalysisPanelTab(undefined);
                                    }}
                                >
                                    <svg width="15" height="15" viewBox="0 0 26 26" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M25.25 3.2175L22.7825 0.75L13 10.5325L3.2175 0.75L0.75 3.2175L10.5325 13L0.75 22.7825L3.2175 25.25L13 15.4675L22.7825 25.25L25.25 22.7825L15.4675 13L25.25 3.2175Z"
                                            fill="#343842"
                                        />
                                    </svg>
                                </div>
                            </div>
                        )}
                    </>
                )}

                {!isMobile && isChatHistoryOpen && (
                    <Panel isOpen={isChatHistoryOpen} onDismiss={() => setIsChatHistoryPanelOpen(false)} isBlocking={false} style={{ width: "100%" }}>
                        <ChatHistory
                            id={conversationId}
                            selectedConversationThread={selectedConversationThread}
                            history={history}
                            isChatHistoryLoaded={isChatHistoryLoaded}
                            deleteConversationThread={deleteConversationThread}
                        />
                    </Panel>
                )}

                {isMobile && isChatHistoryOpen && (
                    <Panel isOpen={isChatHistoryOpen} onDismiss={() => setIsChatHistoryPanelOpen(false)} isBlocking={false} style={{ width: "85%" }}>
                        <ChatHistory
                            id={conversationId}
                            selectedConversationThread={selectedConversationThread}
                            history={history}
                            deleteConversationThread={deleteConversationThread}
                        />
                    </Panel>
                )}
                <Modal open={adjustPanelModal} onClose={handleCloseAdjustPanelModal}>
                    <Box
                        sx={{
                            position: "absolute" as "absolute",
                            top: "50%",
                            left: "50%",
                            transform: "translate(-50%, -50%)",
                            width: "90%",
                            maxWidth: "1120px",
                            bgcolor: "background.paper",
                            boxShadow: 24,
                            outline: 0,
                            p: 2,
                            overflowY: "auto",
                            height: "95%",
                            maxHeight: isMobile ? "940px" : "600px",
                            borderRadius: 3.75,
                            paddingTop: 0
                        }}
                    >
                        <div className={styles.AdjustContainer}>
                            <div style={{ textAlign: "end" }}>
                                <svg
                                    onClick={handleCloseAdjustPanelModal}
                                    width="15"
                                    height="15"
                                    viewBox="0 0 26 26"
                                    fill="none"
                                    xmlns="http://www.w3.org/2000/svg"
                                >
                                    <path
                                        d="M25.25 3.2175L22.7825 0.75L13 10.5325L3.2175 0.75L0.75 3.2175L10.5325 13L0.75 22.7825L3.2175 25.25L13 15.4675L22.7825 25.25L25.25 22.7825L15.4675 13L25.25 3.2175Z"
                                        fill="#343842"
                                    />
                                </svg>
                            </div>
                            <span className={styles.AdjustTitile}>Configure answer generation</span>
                        </div>
                        <div className={styles.groupOne}>
                            <SpinButton
                                className={styles.chatSettingsSeparator}
                                label="Retrieve this many documents from search:"
                                min={1}
                                max={50}
                                defaultValue={retrieveCount.toString()}
                                onChange={onRetrieveCountChange}
                            />
                            <ResponseLengthButtonGroup
                                themeColor={envConfig?.application_theme_color}
                                className={styles.chatSettingsSeparator}
                                onClick={onResponseLengthChange}
                                defaultValue={responseLength}
                            />
                            <ResponseTempButtonGroup
                                themeColor={envConfig?.application_theme_color}
                                className={styles.chatSettingsSeparator}
                                onClick={onResponseTempChange}
                                defaultValue={responseTemp}
                            />
                            {/* <Checkbox styles={checkBoxStyles} label="Controlled checkbox" checked={isChecked} onChange={onChange} /> */}
                            <div className={customCheckboxStyles}>
                                <Checkbox
                                    className={styles.chatSettingsSeparator}
                                    checked={useSuggestFollowupQuestions}
                                    label="Suggest follow-up questions"
                                    onChange={onUseSuggestFollowupQuestionsChange}
                                />
                            </div>
                        </div>
                        <Separator className={styles.chatSettingsSeparator}>Filter search results by</Separator>
                        <div className={styles.groupTwo}>
                            <FolderPicker allowFolderCreation={false} 
                            onSelectedKeyChange={onSelectedKeyChanged} 
                            preSelectedKeys={selectedFolders}
                             />


<FolderPickerNested allowFolderCreation={false} 
                            onSelectedKeyChange={onSelectedKeyChanged} 
                            preSelectedKeys={selectedFolders}
                             />



                            <FileDropdown onFileSelectChange={onSelectedFileChanged} selectedFolders={selectedFolders} preSelectedKeys={selectedFiles} />
                            <TagPickerInline allowNewTags={false} onSelectedTagsChange={onSelectedTagsChange} preSelectedTags={selectedTags} />
                        </div>

                        <Separator className={styles.chatSettingsSeparator}>Advanced settings</Separator>

                        <div className={styles.groupThree}>
                            {envConfig?.advanced_settings[0].use_lite_llm && (
                                <div className={styles.folderArea}>
                                    <div className={styles.folderSelection}>
                                        <ComboBox
                                            label="Model selection:"
                                            selectedKey={modelName ? modelName.key : envConfig?.model_collection[0]?.key || []}
                                            onChange={onModelNameChange}
                                            options={envConfig?.model_collection}
                                        />
                                        <TooltipHost content={"Allows you to specify a model for answer generation"} styles={hostStyles}>
                                            <Info16Regular></Info16Regular>
                                        </TooltipHost>
                                    </div>
                                </div>
                            )}
                            {envConfig?.advanced_settings[0].retriever_feature && (
                                <div className={styles.folderArea}>
                                    <div className={styles.folderSelection}>
                                        <ComboBox
                                            label="Retriever selection:"
                                            selectedKey={retriverFeature ? retriverFeature.key : envConfig?.retriever_feature[0]?.key}
                                            options={envConfig?.retriever_feature}
                                            onChange={onRetriverFeatureChange}
                                        />
                                        <TooltipHost content={queryTooltip} styles={hostStyles}>
                                            <Info16Regular></Info16Regular>
                                        </TooltipHost>
                                    </div>
                                </div>
                            )}

                            {envConfig?.advanced_settings[0].query_transformation_type && (
                                <div className={styles.folderArea}>
                                    <div className={styles.folderSelection}>
                                        <ComboBox
                                            label="Query transformation type selection:"
                                            selectedKey={queryTransformationKey ? queryTransformationKey.key : envConfig?.query_transformation_type[0]?.key}
                                            options={envConfig?.query_transformation_type}
                                            onChange={onQueryTransformationChange}
                                        />
                                        <TooltipHost content={queryTooltip} styles={hostStyles}>
                                            <Info16Regular></Info16Regular>
                                        </TooltipHost>
                                    </div>
                                </div>
                            )}
                            {envConfig?.source_date_range && (
                                <div className={styles.folderArea}>
                                    <div className={styles.folderSelection}>
                                        <ComboBox
                                            placeholder="Select Date"
                                            label="Select source date"
                                            selectedKey={sourceDateKey ? sourceDateKey.key : ""}
                                            options={envConfig?.source_date_range}
                                            onChange={onSourceDateChange}
                                        />
                                        <TooltipHost content={"Date range to filter the corpus data"} styles={hostStyles}>
                                            <Info16Regular></Info16Regular>
                                        </TooltipHost>
                                    </div>
                                </div>
                            )}

                            {envConfig?.advanced_settings[0].show_kpmg_trust_score && (
                                <div className={customCheckboxStyles}>
                                    <Checkbox
                                        className={styles.kpmgTrustScore}
                                        checked={enableCompositeScore}
                                        label="Show KPMG trust score"
                                        onChange={onEnableCompositeScore}
                                    />
                                </div>
                            )}


                        </div>
                    </Box>
                </Modal>

                {envConfig?.advanced_settings[0]?.show_rag_eval_score && (
                    <Panel
                        headerText="RAG evaluation score"
                        isOpen={isRagPanelOpen}
                        isBlocking={false}
                        onDismiss={() => setIsRagPanelOpen(false)}
                        closeButtonAriaLabel="Close"
                        onRenderFooterContent={() => <DefaultButton onClick={() => setIsRagPanelOpen(false)}>Close</DefaultButton>}
                        isFooterAtBottom={true}
                    >
                        {ragData.length > 0 && (
                            <div className={styles.resultspanel}>
                                <div>
                                    {ragData.map(function (i: any, index: number) {
                                        return (
                                            <Accordion
                                                expanded={true}
                                                sx={{
                                                    marginBottom: "10px",
                                                    marginTop: "10px",
                                                    color: "rgb(50, 49, 48)",
                                                    boxShadow: "0 2px 4px #ffffff24,0 0 2px #ffffff1f"
                                                }}
                                            >
                                                <AccordionSummary aria-controls="panel2a-content" id="panel2a-header">
                                                    <Typography>{i?.top_result === true ? "Selection with best score" : "Selected options"}</Typography>
                                                </AccordionSummary>
                                                <AccordionDetails>
                                                    <Typography>
                                                        <div className={styles.ragScore}>
                                                            <label>No. of Retriever results:</label> <span>{i.n_retriever_results}</span>
                                                        </div>
                                                        <div className={styles.ragScore}>
                                                            <label>Retriever feature:</label> <span>{i.retriever_feature}</span>
                                                        </div>
                                                        <div className={styles.ragScore}>
                                                            <label>Query transformation type:</label> <span>{i.query_transformation_type}</span>
                                                        </div>
                                                        <Separator className={styles.chatSettingsSeparator}>Score</Separator>
                                                        <div className={styles.ragScore}>
                                                            <label>Context relevancy:</label> <span>{i.Score_context_relevancy.toFixed(2)}</span>
                                                        </div>
                                                        <div className={styles.ragScore}>
                                                            <label>Context recall:</label> <span>{i.Score_context_recall.toFixed(2)}</span>
                                                        </div>
                                                        <div className={styles.ragScore}>
                                                            <label>Answer relevancy:</label> <span>{i.Score_Answer_Relevancy.toFixed(2)}</span>
                                                        </div>
                                                        <div className={styles.ragScore}>
                                                            <label>Faithfullness:</label> <span>{i.Score_Faithfullness.toFixed(2)}</span>
                                                        </div>
                                                    </Typography>
                                                </AccordionDetails>
                                            </Accordion>
                                        );
                                    })}
                                </div>
                            </div>
                        )}
                    </Panel>
                )}
                <Panel
                    headerText="Information"
                    isOpen={isInfoPanelOpen}
                    isBlocking={false}
                    onDismiss={() => setIsInfoPanelOpen(false)}
                    closeButtonAriaLabel="Close"
                    onRenderFooterContent={() => <DefaultButton onClick={() => setIsInfoPanelOpen(false)}>Close</DefaultButton>}
                    isFooterAtBottom={true}
                >
                    <div className={styles.resultspanel}>
                        <InfoContent />
                    </div>
                </Panel>
               
            
      </div>
    );
};

export default Chat;