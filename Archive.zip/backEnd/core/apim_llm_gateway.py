import requests
class OpenAIAzureAPIMSDK:
    def __init__(self, apim_url, deployment_name, api_version, subscription_key):
        self.apim_url = apim_url
        self.deployment_name = deployment_name
        self.api_version = api_version
        self.subscription_key = subscription_key
        self.headers = {
            "Content-Type": "application/json",
            "api-key": self.subscription_key
        }

    def chat_completions(self, deployment_name, messages, temperature=0.7, top_p=0.95, max_tokens=800, 
        stream=False, stream_options=None):
        url = f"{self.apim_url}/deployments/{deployment_name}/chat/completions?api-version={self.api_version}"
        json_payload = {
            "messages": messages,
            "temperature": temperature,
            "top_p": top_p,
            "max_tokens": max_tokens
        }
        response = requests.post(url, headers=self.headers, json=json_payload)
        return response

    def chat_completions_streaming(self, deployment_name, messages, temperature=0.7, top_p=0.95, n=1, max_tokens=800, 
        stream=False, stream_options=None):
        url = f"{self.apim_url}/deployments/{deployment_name}/chat/completions?api-version={self.api_version}"
        json_payload = {
            "messages": messages,
            "temperature": temperature,
            "top_p": top_p,
            "max_tokens": max_tokens,
            "stream": stream,
            "stream_options": stream_options,
            "n": n
        }
        response = requests.post(url, headers=self.headers, json=json_payload)
        return response    
