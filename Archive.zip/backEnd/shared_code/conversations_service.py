import os
import uuid
import time
from datetime import datetime
from flask import Flask, request
from azure.identity import DefaultAzureCredential  
from azure.cosmos import CosmosClient, PartitionKey  
import json

class CosmosConversationClient():
    ACTIVE = "active"
    DEACTIVE = "deactive"
    SHARABLE = "sharable"
    def __init__(self, cosmosdb_endpoint: str, credential: any, database_name: str, container_name: str, message_container_name: str, feedback_conatiner_name: str, collections_conatiner_name:str):
        self.cosmosdb_endpoint = cosmosdb_endpoint
        self.credential = credential
        self.database_name = database_name
        self.container_name = container_name
        self.message_container_name = message_container_name
        self.feedback_container_name = feedback_conatiner_name
        self.collections_conatiner_name = collections_conatiner_name
        self.cosmosdb_client = CosmosClient(self.cosmosdb_endpoint, credential=credential)
        self.database_client = self.cosmosdb_client.get_database_client(database_name)
        self.container_client = self.database_client.get_container_client(container_name)
        

        
        # Select a database (will create it if it doesn't exist)
        self.database_client = self.cosmosdb_client.get_database_client(self.database_name)
        if self.database_name not in [db['id'] for db in self.cosmosdb_client.list_databases()]:
            self.database_client = self.cosmosdb_client.create_database(self.database_name)

        # Select a container (will create it if it doesn't exist)
        self.container_client = self.database_client.get_container_client(container_name)
        if self.container_name not in [container['id'] for container
                                        in self.database_client.list_containers()]:
            self.container_client = self.database_client.create_container(id=self.container_name,
                partition_key=PartitionKey(path="/userId"))
            
        self.messages_container_client = self.database_client.get_container_client(message_container_name)
        if self.message_container_name not in [container['id'] for container
                                        in self.database_client.list_containers()]:
            self.messages_container_client = self.database_client.create_container(id=self.message_container_name,
                                                                                   partition_key=PartitionKey(path="/conversationId"))

        self.feedback_container_client = self.database_client.get_container_client(self.feedback_container_name)
        print(self.feedback_container_name)
        if self.feedback_container_name not in [container['id'] for container
                                        in self.database_client.list_containers()]:
            self.feedback_container_client = self.database_client.create_container(id=self.feedback_container_name,
                partition_key=PartitionKey(path="/message_id"))
            
                # self.collections_conatiner_name = "chat_collections"
        self.collections_conatiner = self.database_client.get_container_client(self.collections_conatiner_name)
        
        if self.collections_conatiner_name not in [container['id'] for container
                                        in self.database_client.list_containers()]:
            self.collections_conatiner = self.database_client.create_container(id=self.collections_conatiner_name,
                partition_key=PartitionKey(path="/id"))

    def ensure(self):
        try:
            container_info = self.container_client.read()
            if not container_info:
                return False
            
            return True
        except:
            return False

    def create_conversation(self, user_id, title = '', description=''):
        new_data = {
            'id': str(uuid.uuid4()),  
            'type': 'conversation',
            'createdAt': datetime.utcnow().isoformat(),  
            'updatedAt': datetime.utcnow().isoformat(),  
            'userId': user_id,
            'title': title,
            'description': description
        }
         # Filename where the JSON data is stored
        filename = 'conversations.json'

 

            # Read the existing data from the file
        with open(filename, 'r') as file:
            data = json.load(file)  # `data` is a list of dictionaries

            # Append the new data
        data.append(new_data)

            # Write the updated data back to the file
        with open(filename, 'w') as file:
                json.dump(data, file, indent=4)  

        return new_data
    
    def upsert_conversation(self, conversation):
        resp = self.container_client.upsert_item(conversation)
        if resp:
            return resp
        else:
            return False
    
    

    def replace_message(self, message):
        try:
            resp = self.messages_container_client.replace_item(item=message['id'], partition_key=message['conversationId'], body=message)
            if resp:
                return True, resp
            else:
                return None, "Unable to save the chat feedback"
        except Exception as err:
            return None, {"error": str(err)}
        
    def create_message(self, conversation_id, user_id, input_message: dict):
        try:
            message = {
                'id': str(uuid.uuid4()),
                'type': 'message',
                'userId' : user_id,
                'createdAt': datetime.utcnow().isoformat(),
                'updatedAt': datetime.utcnow().isoformat(),
                'conversationId' : conversation_id,
                'role': input_message['role'],
                'content': input_message['content'],
                'citation_lookup': input_message.get('citation_lookup', ''),
                'data_points': input_message.get('data_points', ''),
                'thoughts' : input_message.get('thoughts', ''),
                'scores':  input_message.get('scores', {}),
                'usage': input_message.get('usage', {}),
                'model': input_message.get('model', {}),
                'latency': input_message.get('latency', {}),
                'feedback_type': input_message.get('feedback_type', '')
            }
            
            resp = self.messages_container_client.upsert_item(message)  
            if resp:
                ## update the parent conversations's updatedAt field with the current message's createdAt datetime value
                conversation = self.get_chat_conversation(conversation_id)
                conversation['updatedAt'] = message['createdAt']
                self.upsert_conversation(conversation)
                return resp
            else:
                return False
        except Exception as e:
            return {"error": str(e)}

    def get_chat_conversation(self, conversation_id):
        parameters = [
            {
                'name': '@conversationId',
                'value': conversation_id
            }
        ]
        query = f"SELECT c.id, c.type, c.description, c.createdAt, c.updatedAt, c.userId, c.title FROM c where c.id = @conversationId and c.type='conversation' "
        conversation = list(self.container_client.query_items(query=query, parameters=parameters,
                                                                               enable_cross_partition_query =True))
        ## if no conversations are found, return None
        if len(conversation) == 0:
            return None
        else:
            return conversation[0]
        
    def get_conversation(self, conversation_id = None, user_id = None):
        try:
            if conversation_id:
                conversation = []
                conversation.append(self.get_chat_conversation(conversation_id))
            else:
                if user_id:
                    params = [
                    {
                        "name": "@userId",
                        "value": user_id
                    }
                    ]
                    query = f"SELECT c.id, c.title, c.description, c.updatedAt, (IS_DEFINED(c.is_favorite) = true ? c.is_favorite : false) as is_favorite FROM c where c.userId=@userId ORDER BY c.createdAt DESC"
                else:
                    params = []
                    query = f"SELECT c.id, c.title, c.description, c.updatedAt, (IS_DEFINED(c.is_favorite) = true ? c.is_favorite : false) as is_favorite  FROM c ORDER BY c.createdAt DESC"
                
                conversation = list(self.container_client.query_items(query=query, parameters=params,
                                                                                enable_cross_partition_query =True))
                # conversation = list(self.container_client.read_all_items())
            
            if conversation == None:
                return []
            
            return conversation
        except Exception as ex:
            raise ex
    def get_message_using_convesationId(self, conversation_id):
        try:
            params = [
                {
                    "name": "@conversationId",
                    "value": conversation_id
                }
            ]

            query = f"SELECT * FROM c where c.conversationId = @conversationId ORDER BY c.createdAt"
            message = list(self.messages_container_client.query_items(query=query, parameters=params,
                                                                                enable_cross_partition_query =True))
            if len(message)<1:
                return []
            return message
        except Exception as err:
            raise err

    

    def get_all_messages(self):
        try:
            
            messages = list(self.messages_container_client.read_all_items())
            
            if messages == None:
                return []
            
            return messages
        except Exception as ex:
            raise ex
        
    def delete_conversation(self, conversation_id):
        try:
            conversation = self.get_chat_conversation(conversation_id)        
            if conversation:
                self.container_client.delete_item(item=conversation_id, partition_key=conversation.get('userId'))
                return True
            else:
                return True
        except Exception as ex:
            return None

    def delete_conversation_messages(self, conversation_id):
        try:
            messages = self.get_message_using_convesationId(conversation_id)
            if messages:
                for message in messages:
                    self.messages_container_client.delete_item(item=message['id'], partition_key=conversation_id)
                return True
            else:
                return True
        except Exception as ex:
            raise ex
    
    def delete_conversation_and_message(self, conversation_id):
        try:
            delete_messages = self.delete_conversation_messages(conversation_id)
            deleted_conversation = self.delete_conversation(conversation_id)
            if delete_messages and deleted_conversation:
                return True
            return False
        except Exception as err:
            return False
    
    def get_message_using_id(self, message_id):
        try:
            params = [
                {
                    "name": "@messageId",
                    "value": message_id
                }
            ]

            query = f"SELECT * FROM c where c.id = @messageId"
            message = list(self.messages_container_client.query_items(query=query, parameters=params,
                                                                                enable_cross_partition_query =True))
            if len(message)<1:
                return []
            return message[0]
        except Exception as err:
            raise err        

    def add_feedback(self, message: dict, input_data: dict):
        try:
            feedback_obj = {
                'id': str(uuid.uuid4()),
                'createdAt': datetime.utcnow().isoformat(),
                'updatedAt': datetime.utcnow().isoformat(),
                'message_id' : message.get('id'),
                'conversation_id': input_data.get('conversationId'),
                'feedback_type': input_data.get('feedback_type'),
                'user_comment': input_data.get('user_comment')
            }
            
            resp = self.feedback_container_client.upsert_item(feedback_obj)
            if resp:
                message['updatedAt'] = resp['updatedAt']
                self.messages_container_client.upsert_item(message)
                input_data['createdAt'] = resp['createdAt']
                input_data['updatedAt'] = resp['updatedAt']
                input_data['id'] = resp['id']
                return input_data, 201
            else:
                return False, 500
        except Exception as e:
            return {"error": str(e)}, 500
        
        
    def save_workspace(self, input_data: dict):
        try:
            obj = {
                'id': str(uuid.uuid4()),
                'createdAt': datetime.utcnow().isoformat(),
                'updatedAt': datetime.utcnow().isoformat(),
                'workspace_name': input_data.get('workspace_name'),
                'status': self.ACTIVE,
                'deleted': False,
                'description': input_data.get('description'),
                'privacy': input_data.get('privacy'),
                'user_id': input_data.get('user_id')
                # 'prompt': input_data.get('prompt')
            }
            
            resp = self.collections_conatiner.upsert_item(obj)
            if resp:
                input_data['createdAt'] = resp['createdAt']
                input_data['updatedAt'] = resp['updatedAt']
                input_data['id'] = resp['id']
                return input_data, 201
            else:
                return False, 500
        except Exception as e:
            return {"error": str(e)}, 500
    
    def get_workspace(self, workspace_name):
        parameters = [
            {
                'name': '@workspace_name',
                'value': workspace_name
            }
        ]
        query = f"SELECT * FROM c where c.workspace_name = @workspace_name "
        result = list(self.collections_conatiner.query_items(query=query, parameters=parameters,
                                                                               enable_cross_partition_query =True))
        ## if no conversations are found, return None
        if len(result) == 0:
            return None
        else:
            return result[0]
    
    def get_workspace_by_id(self, workspace_id):
        parameters = [
            {
                'name': '@workspace_id',
                'value': workspace_id
            }
        ]
        query = f"SELECT * FROM c where c.id = @workspace_id"
        result = list(self.collections_conatiner.query_items(query=query, parameters=parameters,
                                                                               enable_cross_partition_query =True))
        ## if no conversations are found, return None
        if len(result) == 0:
            return None
        else:
            return result[0]

    def check_unique_workspace_name(self, workspace_id, workspace_name):
        parameters = [
            {
                'name': '@workspace_id',
                'value': workspace_id
            },
            {
                'name': '@workspace_name',
                'value': workspace_name
            }
        ]
        query = f"SELECT * FROM c where c.id != @workspace_id and c.workspace_name = @workspace_name "
        result = list(self.collections_conatiner.query_items(query=query, parameters=parameters,
                                                                               enable_cross_partition_query =True))
        ## if no conversations are found, return None
        if len(result) == 0:
            return None
        else:
            return result[0]

    def delete_workspace(self, workspace_id):
        try:
            workspace = self.get_workspace_by_id(workspace_id)        
            if workspace:
                self.collections_conatiner.delete_item(item=workspace_id, partition_key=workspace.get('id'))
                return True
            else:
                return True
        except Exception as ex:
            return None
    
    def update_workspace(self, workspace_info):
        resp = self.collections_conatiner.upsert_item(workspace_info)
        if resp:
            return resp
        else:
            return False
    def get_workspace_list(self, user_id):
        parameters = [
            {
                'name': '@user_id',
                'value': user_id
            }
        ]
        query = f"SELECT c.id,c.workspace_name, c.privacy, c.user_id, c.description FROM c where c.deleted =false AND c.user_id = @user_id "
        result = list(self.collections_conatiner.query_items(query=query, parameters=parameters,
                                                                                enable_cross_partition_query =True))
        ## if no workspace are found, return None
        if len(result) == 0:
            return []
        else:
            return result
    
    
    def get_conversation_id_using_workspace_id(self, workspace_id):
        parameters = [
            {
                'name': '@workspace_id',
                'value': workspace_id
            }
        ]
        query = f"SELECT c.id FROM c where c.workspace = @workspace_id and c.type='conversation' "
        conversation = list(self.container_client.query_items(query=query, parameters=parameters,
                                                                               enable_cross_partition_query =True))
        ## if no conversations are found, return None
        if len(conversation) == 0:
            return None
        else:
            return conversation[0]
        
            
    def get_conversation_list_using_workspace_id(self, workspace_id):
        parameters = [
            {
                'name': '@workspace_id',
                'value': workspace_id
            }
        ]
        query = f"SELECT c.id, c.title, c.description FROM c where c.workspace = @workspace_id and c.type='conversation' "
        conversation = list(self.container_client.query_items(query=query, parameters=parameters,
                                                                               enable_cross_partition_query =True))
        ## if no conversations are found, return None
        if len(conversation) == 0:
            return None
        else:
            return conversation
    
    def retrieve_message_by_conversationId(self, conversation_id):
        try:
            params = [
                {
                    "name": "@conversationId",
                    "value": conversation_id
                }
            ]

            query = f"SELECT c.role, c.content FROM c where c.conversationId = @conversationId ORDER BY c.createdAt"
            message = list(self.messages_container_client.query_items(query=query, parameters=params,
                                                                                enable_cross_partition_query =True))
            if len(message)<1:
                return []
            return message
        except Exception as err:
            raise err
