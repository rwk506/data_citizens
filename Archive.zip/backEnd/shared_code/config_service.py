import os
import uuid
from datetime import datetime
from flask import Flask, request
from azure.identity import DefaultAzureCredential  
from azure.cosmos import CosmosClient, PartitionKey  
  
class CosmosConfigClient():
    
    def __init__(self, cosmosdb_endpoint: str, credential: any, database_name: str, 
                 container_name: str, config_container_name: str):
        self.cosmosdb_endpoint = cosmosdb_endpoint
        self.credential = credential
        self.database_name = database_name
        self.container_name = container_name
        self.cosmosdb_client = CosmosClient(self.cosmosdb_endpoint, credential=credential)
        self.database_client = self.cosmosdb_client.get_database_client(database_name)
        self.container_client = self.database_client.get_container_client(container_name)
        self.config_container_name = config_container_name

        
        # Select a database (will create it if it doesn't exist)
        self.database_client = self.cosmosdb_client.get_database_client(self.database_name)
        if self.database_name not in [db['id'] for db in self.cosmosdb_client.list_databases()]:
            self.database_client = self.cosmosdb_client.create_database(self.database_name)

        # Select a container (will create it if it doesn't exist)
        self.container_client = self.database_client.get_container_client(container_name)
        if self.container_name not in [container['id'] for container
                                        in self.database_client.list_containers()]:
            self.container_client = self.database_client.create_container(id=self.container_name,
                partition_key=PartitionKey(path="/id"))
            
        self.config_container_client = self.database_client.get_container_client(config_container_name)
        if self.config_container_name not in [container['id'] for container
                                        in self.database_client.list_containers()]:
            self.config_container_client = self.database_client.create_container(id=self.config_container_name,
                partition_key=PartitionKey(path="/id"))
            
    def ensure(self):
        try:
            container_info = self.container_client.read()
            if not container_info:
                return False
            
            return True
        except:
            return False

    def get_rag_scores(self):
        
        query = f"SELECT c.Score_Answer_Relevancy, c.Score_Bias, c.Score_Faithfullness, c.Score_Toxicity, c.Score_context_recall, c.Score_context_relevancy, c.id, c.n_retriever_results, c.query_transformation_type, c.retriever_feature, c.use_semantic_reranking, c.top_result FROM c ORDER BY c.top_result DESC"
        config_val = list(self.container_client.query_items(query=query, enable_cross_partition_query =True))
        if len(config_val) == 0:
            return None
        else:
            return config_val
        
    def save_prompts(self, prompt, prompt_category):
        try:
            prompt_object = self.get_config(prompt_category) 
            if prompt_object:
                prompt_object['config_value'] = prompt
            else:
                prompt_object = {
                    'id': str(uuid.uuid4()),
                    'createdAt': datetime.utcnow().isoformat(),
                    'updatedAt': datetime.utcnow().isoformat(),
                    'config_key': prompt_category,
                    'config_value': prompt
                }
            
            response = {}
            resp = self.config_container_client.upsert_item(prompt_object)
            if resp:               
                response['createdAt'] = resp['createdAt']
                response['updatedAt'] = resp['updatedAt']
                response['id'] = resp['id']
                response[prompt_category] = resp['config_value']
                return response, 201
            else:
                return False, 500
        except Exception as e:
            raise Exception("Unable to save the prompt")
        
    def get_config(self, config_key):
        try:
            params = [
                {
                    "name": "@config_key",
                    "value": config_key
                }
            ]
            query = f"SELECT * FROM c where c.config_key = @config_key"
            response = list(self.config_container_client.query_items(query=query, parameters=params, enable_cross_partition_query =True))
            
            if len(response)<1:
                return []
            return response[0]
        except Exception as err:
            raise err
        
    def get_config_values(self, config_key):
        try:
            params = [
                {
                    "name": "@config_key",
                    "value": config_key
                }
            ]
            query = f"SELECT c.config_value FROM c where c.config_key = @config_key"
            response = list(self.config_container_client.query_items(query=query, parameters=params, enable_cross_partition_query =True))
            
            if len(response)<1:
                return []
            return response[0]
        except Exception as err:
            raise err