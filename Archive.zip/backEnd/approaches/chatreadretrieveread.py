
import json
import re
import logging
import time
import urllib.parse
from datetime import datetime, timedelta
from typing import Any, Sequence
import os
import openai
from collections import Counter
from approaches.approach import Approach
from boto3 import client
from qdrant_client import QdrantClient

 
from azure.search.documents.models import RawVectorQuery
from azure.search.documents.models import QueryType
import comet_llm
from text import nonewlines
from datetime import datetime, timedelta
from azure.storage.blob import (
    AccountSasPermissions,
    BlobServiceClient,
    ResourceTypes,
    generate_account_sas,
)
import traceback
from text import nonewlines
import tiktoken
from core.messagebuilder import MessageBuilder
from core.modelhelper import get_token_limit
from core.modelhelper import num_tokens_from_messages
import requests
from urllib.parse import quote
import numpy as np
from dateutil.relativedelta import relativedelta

from auth.auth_utils import get_authenticated_user_details
from shared_code.conversations_service import CosmosConversationClient
from utilities.utils import generate_conversation_title, get_index_name, get_rag_eval_scores, summarize_the_conversation
import uuid

from concurrent.futures import ThreadPoolExecutor

# Imports related to HyDE Query Trasnformation
 
 
import traceback
from groq import Groq
# from llama_index.llms.groq import Groq as Groq_llm

import boto3
from llama_index.core import Settings
from llama_index.embeddings.fastembed import FastEmbedEmbedding

from dotenv import load_dotenv
import os
import json
import requests
os.environ['GROQ_API_KEY'] = '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'
 
# Simple retrieve-then-read implementation, using the Cognitive Search and
# OpenAI APIs directly. It first retrieves top documents from search,
# then constructs a prompt with them, and then uses OpenAI to generate
# an completion (answer) with that prompt.

class ChatReadRetrieveReadApproach(Approach):

     # Chat roles
    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"
    
    # system_message_chat_conversation = os.environ.get("SYSTEM_PROMPT")
    
    # follow_up_questions_prompt_content = os.environ.get("FOLLOWUP_QUESTION_PROMPT")
    
    # query_prompt_template = os.environ.get("QUERY_PROMPT_TEMPLATE")
    # try:
    #     query_prompt_few_shots = json.loads(os.environ.get("QUERY_PROMPT_FEW_SHOTS"))
    # except:
    #     query_prompt_few_shots = []
    # try:
    #     response_prompt_few_shots = json.loads(os.environ.get("RESPONSE_PROMPT_FEW_SHOTS"))
    # except:
    #     response_prompt_few_shots = []
    
 
             
    def __init__(
        self
         
    ):
        
        
        self.en = ""
    # AWS credentials
    aws_access_key_id = 'AKIAR5ESAXRDHUTJAJW4'
    aws_secret_access_key = "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"
    aws_default_region = "us-east-1"
    bedrock_model_id = "llama-3-8b"
    dynamodb = boto3.resource(
        'dynamodb',
        aws_access_key_id="AKIAR5ESAXRDHUTJAJW4",
        aws_secret_access_key="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",
        region_name="us-east-1"
    )

    # Fetch data from DynamoDB
    table_name = "meta-chunks"
    table = dynamodb.Table(table_name)
    response = table.scan()
    # print(response)
    items = response['Items']
    # print('items', items[0])

    #### initialize llamaindex
    # client = Groq(api_key= os.environ.get("GROQ_API_KEY"))


    QDRANT_URL = "https://42800922-23b6-4089-a5ab-6f92c30081e3.us-east4-0.gcp.cloud.qdrant.io:6333"
    QDRANT_API_KEY = "xfqv1pUX-i03MY9hz4CHjTXtVT2_ImfolTJ4HDm9Fz_IM6pSFG8i9A"
    collection_name = "example_data3"
    # qdrant_client2 = QdrantClient(
    #     url=QDRANT_URL, 
    #     api_key=QDRANT_API_KEY,
    # )
         
    bedrock_client = client('bedrock', region_name=aws_default_region, 
        aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key)
    
    def id_lookup(self, id_num, items):
        aws_access_key_id = 'AKIAR5ESAXRDHUTJAJW4'
        aws_secret_access_key = "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"
        aws_default_region = "us-east-1"
        bedrock_model_id = "llama-3-8b"
        dynamodb = boto3.resource(
            'dynamodb',
            aws_access_key_id="AKIAR5ESAXRDHUTJAJW4",
            aws_secret_access_key="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",
            region_name="us-east-1"
        )
        table_name = "meta-chunks"
        table = dynamodb.Table(table_name)
        response = table.scan()
        items = response['Items']

        descriptions = [item['Description'] for item in items if (item['ID'])==id_num]
        return descriptions[0]

    def construct_prompt(self, hit, question, history, items=items):
        description = self.id_lookup(hit.payload['ID'], items)

        #metadata = """" TBD From user"""

        print(history, len(history), type(history))
        context = description
        if len(history)>2:
            hist = history[-2]['user'] + ':'+history[-3]['bot'] + history[-1]['user'] + ':'+history[-2]['bot']
            print(hist)
        elif len(history)>1:
            hist = history[-1]['user'] + ':'+history[-2]['bot']
            print(hist)
        elif len(history)>0:
            hist = history[-1]['user']
            print(hist)
        else:
            hist = ''

        sys_prompt = """You are a helpful assistant and professional that works with non profit organizations look for relevant grants that they are eligible for. Be transparent - if you don't know the answer or it isn't clear, do not guess and say it is not clear. Cite relevant reference text whenever possible. Please provide your response in markdown format."""
        user_prompt = 'User question:\n' + \
                        question + \
                        '\nUse the text below to concisely answer the user question:\n' + \
                        '\nGrant information:\n' + \
                        context + '\n' + \
                        '\nPrevious Conversation History:\n' + hist

        # print(context + ''.join(hist))
                        #'\nNon profit applicant information:\n' + \
                        #metadata + \
        # print(sys_prompt, user_prompt)
        return sys_prompt, user_prompt

    def send_prompt(self, sys_prompt, user_prompt, client=client):
        client = Groq(api_key= os.environ.get("GROQ_API_KEY"))
        chat_completion = client.chat.completions.create(
            messages=[
                {
                    "role": "system",
                    "content": sys_prompt
                },
                {
                    "role": "user",
                    "content": user_prompt
                }
            ],
            model="llama3-8b-8192",
        )
        return chat_completion.choices[0].message.content
    
    def add_conversation(self, messages, conversation_id=None, user_id=None, description=None):
        """Inserts the conversation history to the DB
        """
        global message_uuid
        message_uuid = str(uuid.uuid4())
        #authenticated_user = get_authenticated_user_details(request_headers={})
        #user_id = authenticated_user['user_principal_id']

        try:
            message_id = str(uuid.uuid4())
            new_data = {
                'id': message_id,  
                'type': 'conversation',
                'createdAt': datetime.utcnow().isoformat(),  
                'updatedAt': datetime.utcnow().isoformat(),  
                'userId': user_id,
                'title': "{}{}".format("conv-title-", message_id),
                'description': description
            }

           
               
            filename = 'db/conversations.json'
            if not os.path.exists(filename):
                with open(filename, 'w') as file:
                    json.dump([], file)  # Create an empty list in the file

            # Read the existing data from the file
            with open(filename, 'r') as file:
                data = json.load(file)  # `data` is a list of dictionaries

                # Append the new data
            data.append(new_data)

                # Write the updated data back to the file
            with open(filename, 'w') as file:
                    json.dump(data, file, indent=4)  

            return new_data
            # make sure cosmos is configured
            if not self.cosmos_conversation_client:
                return {"error":'CosmosDB is not configured'}

            # check for the conversation_id, if the conversation is not set, we will create a new one
            
            if not conversation_id:
                title = message_uuid
                conversation_dict = self.cosmos_conversation_client.create_conversation(user_id=user_id, title=title, description=description)
                conversation_id = conversation_dict.get('id')
            return {'conversation_id':conversation_id}
        
        except Exception as e:
            logging.exception("Exception in /chat")
            return {"error": str(e)}
    
    def add_user_message(self, user_message, conversation_id):
        """Insert user messages to json
        """
        try:
            global message_uuid
            message_uuid = str(uuid.uuid4())
            authenticated_user = get_authenticated_user_details(request_headers={})
            user_id = authenticated_user['user_principal_id']
            if not conversation_id:
                return {'error': 'No conversation_id found'}
 
            new_data = {
                'id': message_uuid,  
                "role":"user", "content": user_message,
                'type': 'conversation',
                'createdAt': datetime.utcnow().isoformat(),  
                'updatedAt': datetime.utcnow().isoformat(),  
                'userId': user_id,
                'title': "{}{}".format("msg-title-", message_uuid),
                "conversation_id" : conversation_id
            }

              # Filename where the JSON data is stored
            filename = 'db/messages.json' 

            if not os.path.exists(filename):
                with open(filename, 'w') as file:
                    json.dump([], file)  # Create an empty list in the file

                # Read the existing data from the file
            with open(filename, 'r') as file:
                data = json.load(file)  # `data` is a list of dictionaries

                # Append the new data
            data.append(new_data)

                # Write the updated data back to the file
            with open(filename, 'w') as file:
                    json.dump(data, file, indent=4)  

            return new_data
        except Exception as e:
            logging.exception("Exception in /chat")
            return {"error": str(e)}
        
    def add_assistant_message(self, messages, conversation_id):
        """Insert bot response to DB
        """
        try:
            global message_uuid
            message_uuid = str(uuid.uuid4())
            authenticated_user = get_authenticated_user_details(request_headers={})
            user_id = authenticated_user['user_principal_id']
            if not conversation_id:
                return {'error': 'No conversation_id found'}
             
             
            new_data = {
                'id': message_uuid,  
                "role":"assistant", "content": messages,
                'type': 'conversation',
                'createdAt': datetime.utcnow().isoformat(),  
                'updatedAt': datetime.utcnow().isoformat(),  
                'userId': user_id,
                'title': "{}{}".format("msg-title-", message_uuid)
            }

              # Filename where the JSON data is stored
            filename = 'messages.json'

    

                # Read the existing data from the file
            with open(filename, 'r') as file:
                data = json.load(file)  # `data` is a list of dictionaries

                # Append the new data
            data.append(new_data)

                # Write the updated data back to the file
            with open(filename, 'w') as file:
                    json.dump(data, file, indent=4)  

            return new_data
        except Exception as e:
            logging.exception("Exception in /chat")
            return {"error": str(e)}

    def create_embeddings_search(self,generated_query,search_client,use_semantic_captions,overrides,top,history,search_filter):
    # Generate embedding using REST API

        url = f'{self.embedding_service_url}/models/{self.escaped_target_model}/embed'
        data = [f'"{generated_query}"']
        headers = {
                'Accept': 'application/json',  
                'Content-Type': 'application/json',
            }

        response = requests.post(url, json=data,headers=headers,timeout=60)
        if response.status_code == 200:
            response_data = response.json()
            embedded_query_vector =response_data.get('data')         
        else:
            logging.error(f"Error generating embedding:: {response.status_code}")
            yield json.dumps({"error": "Error generating embedding"}) + "\n"
            return # Go no further
        
        
        if overrides.get('retriver_feature') == "multi_vector_query":
            vector = RawVectorQuery(vector=embedded_query_vector, k=top, fields="contentVector, questionsVector")
        else:
            vector = RawVectorQuery(vector=embedded_query_vector, k=top, fields="contentVector")
         
        
        if self.use_comet_llm.lower() in ['yes','true']:
            
            with comet_llm.Span(
                    category="llm-retrieval",
                    inputs={"user_question": history[-1]["user"],'generated_query':generated_query,'filter': search_filter,'top':top},
                ) as context_span:
                
                if (not self.is_gov_cloud_deployment):
                    r = search_client.search(
                        generated_query,
                        query_type=QueryType.SEMANTIC,
                        query_language="en-us",
                        query_speller="lexicon",
                        semantic_configuration_name="default",
                        top= top,
                        query_caption="extractive|highlight-false"
                        if use_semantic_captions else None,
                        vector_queries =[vector],
                        filter=search_filter
                    )
                else:
                    r = search_client.search(
                        generated_query, top=top,vector_queries =[vector], filter=search_filter
                    )
                    

                citation_lookup = {}  # dict of "FileX" moniker to the actual file name
                results = []  # list of results to be used in the prompt
                data_points = []  # list of data points to be used in the response
        
                for idx, doc in enumerate(r):  # for each document in the search results
                    # include the "FileX" moniker in the prompt, and the actual file name in the response
                    results.append(
                        f"File{idx} " + "| " + nonewlines(doc[self.content_field])
                    )
                    data_points.append(
                    "/".join(urllib.parse.unquote(doc[self.source_file_field]).split("/")[4:]
                        ) + "| " + nonewlines(doc[self.content_field])
                        )

                    # add the "FileX" moniker and full file name to the citation lookup
                    citation_lookup[f"File{idx}"] = {
                        "citation": urllib.parse.unquote(f"/{self.content_storage_container}/" + doc[self.chunk_file_field]),
                        "source_path": self.get_source_file_with_sas(doc[self.source_file_field]),
                        "page_number": str(doc[self.page_number_field][0]) or "0",
                    }
                
                context_span.set_outputs(outputs={'number of results':len(results), "results": results})
        else:
            
            if (not self.is_gov_cloud_deployment):
                r = search_client.search(
                    generated_query,
                    query_type=QueryType.SEMANTIC,
                    query_language="en-us",
                    query_speller="lexicon",
                    semantic_configuration_name="default",
                    top= top,
                    query_caption="extractive|highlight-false"
                    if use_semantic_captions else None,
                    vector_queries =[vector],
                    filter=search_filter
                )
            else:
                r = search_client.search(
                    generated_query, top=top,vector_queries =[vector], filter=search_filter
                )
                

            citation_lookup = {}  # dict of "FileX" moniker to the actual file name
            results = []  # list of results to be used in the prompt
            data_points = []  # list of data points to be used in the response
    
            for idx, doc in enumerate(r):  # for each document in the search results
                print('idx: ',idx)
                # include the "FileX" moniker in the prompt, and the actual file name in the response
                results.append(
                    f"File{idx} " + "| " + nonewlines(doc[self.content_field])
                )
                data_points.append(
                "/".join(urllib.parse.unquote(doc[self.source_file_field]).split("/")[4:]
                    ) + "| " + nonewlines(doc[self.content_field])
                    )

                # add the "FileX" moniker and full file name to the citation lookup
                citation_lookup[f"File{idx}"] = {
                    "citation": urllib.parse.unquote(f"/{self.content_storage_container}/" + doc[self.chunk_file_field]),
                    "source_path": self.get_source_file_with_sas(doc[self.source_file_field]),
                    "page_number": str(doc[self.page_number_field][0]) or "0",
                }
        print({'results':results,'citation_lookup':citation_lookup,'data_points':data_points})        
        return {'results':results,'citation_lookup':citation_lookup,'data_points':data_points}

    def get_date_range_in_months(self, number_of_months):
        try:
            todays_date = datetime.utcnow().date()
            from_date = todays_date + relativedelta(months=-number_of_months)
            return from_date.strftime("%Y-%m-%d"), todays_date.strftime("%Y-%m-%d")
        except:
            return '', ''

    def get_date_range_in_days(self, number_of_days):
        try:
            todays_date = datetime.utcnow().date()
            from_date = todays_date + relativedelta(days=-number_of_days)
            return from_date.strftime("%Y-%m-%d"), todays_date.strftime("%Y-%m-%d")
        except:
            return '', ''

    def get_published_date_fileter(self, published_date_filter):
        if published_date_filter:
            get_date_period = published_date_filter.split('-')
            try:
                period_in = get_date_period[1]
            except:
                period_in = ''
            try:
                date_period_in_num = int(get_date_period[0])
            except:
                date_period_in_num = ''

            if period_in == 'months':
                from_date, todays_date = self.get_date_range_in_months(date_period_in_num)
            elif period_in == 'days':
                from_date, todays_date = self.get_date_range_in_days(date_period_in_num)
            else:
                from_date, todays_date = '', ''

            return {'from':from_date, 'to':todays_date}
        return {'from':'', 'to':''}

    # def get_embeddings(self):
    #     print('user query is:', self.user_query)
    #     return self.embed_model.get_text_embedding(self.user_query)

    def retrieve_top_hits(self, embedding, collection_name='example_data3', nhits=5):
        qdrant_client2 = QdrantClient(
                url="https://42800922-23b6-4089-a5ab-6f92c30081e3.us-east4-0.gcp.cloud.qdrant.io:6333", 
                api_key="xfqv1pUX-i03MY9hz4CHjTXtVT2_ImfolTJ4HDm9Fz_IM6pSFG8i9A",
            )

        hits = qdrant_client2.query_points(
            'example_data3',
            # query=self.get_embeddings(), #groc
            query = embedding,
            # using="text",
            limit=nhits,
        ).points

        return hits

    def summarizationPipeline(self, user_query):
        # self.user_query = user_query
        # # llm = Groq_llm(model="llama3-70b-8192", api_key=api_key = os.environ.get("GROQ_API_KEY"))
        # llm = Groq(api_key= os.environ.get("GROQ_API_KEY"))
        # Settings.llm = llm
        # self.embed_model = FastEmbedEmbedding(model_name="BAAI/bge-small-en-v1.5")
        # Settings.embed_model = self.embed_model

        client = boto3.client("bedrock-runtime", region_name="us-east-1")
        model_id = "amazon.titan-embed-text-v2:0"
        native_request = {"inputText": user_query}
        request = json.dumps(native_request)
        response = client.invoke_model(modelId=model_id, body=request)
        model_response = json.loads(response["body"].read())
        embedding = model_response["embedding"]
        return embedding

    async def generate(self, history, overrides, 
            conversation_id: str = None, start_time: Any = None,user_id: str = None) -> Any:
        print("ENTER")
        
        qdrant_client2 = QdrantClient(
            url="https://42800922-23b6-4089-a5ab-6f92c30081e3.us-east4-0.gcp.cloud.qdrant.io:6333", 
            api_key="xfqv1pUX-i03MY9hz4CHjTXtVT2_ImfolTJ4HDm9Fz_IM6pSFG8i9A",
        )

        try:
            question = history[-1]["user"]
            count = len(history)
            print(count)
            embd = self.summarizationPipeline(question)
            results = self.retrieve_top_hits(embd, qdrant_client2)
            import re
            response_str = ''
            if count == 1:
                for h in results:
                    response_str+= 'Grant Name: ' + h.payload['GrantName'] + '\nGrant Provider: ' + h.payload['GrantProvider'] + '\nGrant Description: ' + '\n'  + re.search( '\"text\":[\w\W]{,4000}\"\, \"mime', h.payload['_node_content']).group(0)[9:-12]  + '\n\n'
                yield json.dumps({"content": str(response_str) }) + "\n"
            # count+=1

            sys_prompt, user_prompt = self.construct_prompt(results[0], question, history)
            response = self.send_prompt(sys_prompt, user_prompt)
          
            print("------response-----")
            answer = "System generated Message"

            #user_message = history[0]["user"]
            conversation_id, message_id = await self.chat_insertion(message_content=answer,history=history,conversation_id=conversation_id,user_id=user_id,
                                                                    user_message=question, start_time=start_time)

            yield json.dumps({"content": str(response) }) + "\n"
            answer = " ".join(str(response))   
            print(response)

            yield json.dumps({"answer": str('pgiehapghieai'), "data_points" : [],"conversation_id": conversation_id,
                "message_id": message_id, }) + "\n"
            

        except Exception as err:
            logging.error(f"Error /chat:: {str(traceback.format_exc())}")
            
            yield json.dumps({"error": f"Error generating chat completion: {str(err)}"}) + "\n"
            return
            
        
    async def chat_insertion(self, message_content,  history, user_message, conversation_id=None,user_id=None, **kwargs  ):
        print(">>>>>>>>>>",message_content)
        db_resp = {}
        latency = ''
        if not conversation_id:
            if message_content:
                description = "Conversation"
                store_chat_conversation = self.add_conversation(history, conversation_id=conversation_id, user_id=user_id, description=description)
                conversation_id = store_chat_conversation.get('id')

      
        if conversation_id: 
            self.add_user_message(user_message, conversation_id)
            latency = round((time.time() - kwargs.get('start_time')), 2)
            assistant_msg_collection = {
                                        "content":f"{urllib.parse.unquote(message_content)}",
                                     
                                     
                                        "thoughts": f"Searched for:<br>",
                                        
                                        }
            db_resp = self.add_assistant_message(assistant_msg_collection, conversation_id)
            if not db_resp.get('id'):
                raise Exception("Failed to store message in db")
        
        return conversation_id, db_resp.get('id')

    #Aparmar. Custom method to construct Chat History as opposed to single string of chat History.
    def get_messages_from_history(
        self,
        system_prompt: str,
        model_id: str,
        history: Sequence[dict[str, str]],
        user_conv: str,
        few_shots = [],
        max_tokens: int = 4096) -> []:
        """
        Construct a list of messages from the chat history and the user's question.
        """
        message_builder = MessageBuilder(system_prompt, model_id)

        # Few Shot prompting. Add examples to show the chat what responses we want. It will try to mimic any responses and make sure they match the rules laid out in the system message.
        for shot in few_shots:
            message_builder.append_message(shot.get('role'), shot.get('content'))

        user_content = user_conv
        append_index = len(few_shots) + 1

        message_builder.append_message(self.USER, user_content, index=append_index)
        
        for h in reversed(history[:-1]):
            if h.get("bot"):
                message_builder.append_message(self.ASSISTANT, h.get('bot'), index=append_index)
            message_builder.append_message(self.USER, h.get('user'), index=append_index)
            if message_builder.token_length > max_tokens:
                break
        
        messages = message_builder.messages
        return messages

    #Get the prompt text for the response length
    def get_response_length_prompt_text(self, response_length: int):
        """ Function to return the response length prompt text"""
        levels = {
            1024: "succinct",
            2048: "standard",
            3072: "thorough",
        }
        level = levels[response_length]
        return f"Please provide a {level} answer. This means that your answer should be no more than {response_length} tokens long."

    def num_tokens_from_string(self, string: str, encoding_name: str) -> int:
        """ Function to return the number of tokens in a text string"""
        encoding = tiktoken.get_encoding(encoding_name)
        num_tokens = len(encoding.encode(string))
        return num_tokens

    def get_source_file_with_sas(self, source_file: str) -> str:
        """ Function to return the source file with a SAS token"""
        try:
            sas_token = generate_account_sas(
                self.blob_client.account_name,
                self.blob_client.credential.account_key,
                resource_types=ResourceTypes(object=True, service=True, container=True),
                permission=AccountSasPermissions(
                    read=True,
                    write=True,
                    list=True,
                    delete=False,
                    add=True,
                    create=True,
                    update=True,
                    process=False,
                ),
                expiry=datetime.utcnow() + timedelta(self.sas_token_expiry),
            )
            AZURE_BLOB_STORAGE_ENDPOINT = os.environ.get("AZURE_BLOB_STORAGE_ENDPOINT") 
            new_source_file = source_file.replace(AZURE_BLOB_STORAGE_ENDPOINT, "")
            
            return new_source_file + "?" + sas_token
        except Exception as error:
            logging.error(f"Unable to parse source file name: {str(error)}")
            return ""    
    
    async def llm_chat_completion(self, deployment_name, client, messages, max_tokens=1000, temperature=0.0,stream=True, stream_options=False):
        
        
        chat_completion = await client.chat.completions.create(
                        model=deployment_name, 
                        messages=messages,
                        max_tokens=max_tokens, 
                        temperature=temperature,
                        n=1,
                        stream=stream,
                        stream_options={"include_usage": True}
                        )
        
        return chat_completion
    
    async def llm_chat_completion_non_streaming(self, deployment_name, client, messages, max_tokens=1000, temperature=0.0,stream=True, stream_options=False):
        
        
        chat_completion = await client.chat.completions.create(
                        model=deployment_name, 
                        messages=messages,
                        max_tokens=max_tokens, 
                        temperature=temperature,
                        n=1
                        )
        
        return chat_completion
    
    async def external_llmcall_using_litellm(self, overrides, history):
        try:
            system_message = ""
            messages = self.get_messages_from_history(
                            system_message,
                            self.model_name,
                            history,
                            history[-1]["user"], 
                            self.response_prompt_few_shots,
                            max_tokens=self.chatgpt_token_limit - 100
                        )
            chat_completion = await self.llm_client.chat.completions.create(
                                model=overrides.get('model_name'),
                                messages=messages, 
                                max_tokens=overrides.get('max_tokens') or 1024,
                                stream=True,
                                temperature= (overrides.get("response_temp") and float(overrides.get("response_temp"))) or 0.6 )            
            async for chunk in chat_completion:
                # Check if there is at least one element and the first element has the key 'delta'
                if len(chunk.choices) > 0:
                    yield json.dumps({"content": chunk.choices[0].delta.content}) + "\n"

           ## yield ""
        except Exception as error:
            logging.error(f"Unable to generate the chat response: {str(error)}")
            yield ""
            return
    def transform_data(self, data):
        transformed = []
        for i in range(0, len(data), 2):
            user_data = ''
            bot_data = ''
            if data[i]["role"] == 'user':    
                try:
                    user_data = data[i]["content"]
                except:
                    user_data = ''
                try:    
                    bot_data = data[i+1]["content"]
                except:
                    bot_data = ''
            
            transformed.append({
                "user": user_data,
                "bot": bot_data
            })
        return transformed


    def get_chat_conversations(self, conversation_id):
        conversation_messages = self.cosmos_conversation_client.retrieve_message_by_conversationId(conversation_id)
        history = self.transform_data(conversation_messages)
        return history

            
        
    def summarizer(self, conversation_id ):
        
        system_message = os.environ.get("SYSTEM_PROMPT_SUMMARY")
        history = self.get_chat_conversations(conversation_id)
        
        if len(history) == 1:
           history.append({'user':'', 'bot':''})
        
        messages = self.get_messages_from_history(
                            system_message,
                            self.model_name,
                            history,
                            system_message,
                            [],
                            max_tokens=self.chatgpt_token_limit
                        )
        summary = summarize_the_conversation(messages, self.openai_url, self.openai_key, self.chatgpt_deployment)
        if summary:
            # Store the information in DB.
            conversation = self.cosmos_conversation_client.get_chat_conversation(conversation_id)
            conversation["description"] = summary
            conversation['updatedAt'] = datetime.utcnow().isoformat()
            update_conv = self.cosmos_conversation_client.upsert_conversation(conversation)
            if not update_conv:
                raise Exception("Failed to store summary details in db")
        return summary

    def formatting_message_to_summarize(self, answer, question):
        prompt = os.environ.get("SYSTEM_PROMPT_SUMMARY", "Summarize the conversation so far into a 2 sentnces or less. Do not use any quotation marks or punctuation.")
        if not question:
            question = '' 
        messages = [{'role': "user", 'content': question }, {'role': "assistant", 'content': answer}]
        messages.append({'role': 'system', 'content': prompt})
        return messages
    
        
    async def llm_gateway_chat_completion(self, client, deployment_name, messages, top_p=0.95, max_tokens=1000, 
                                          temperature=0.0,stream=False, stream_options=False):
        chat_completion = client.chat_completions(
                        deployment_name=deployment_name, 
                        messages=messages,
                        max_tokens=max_tokens, 
                        temperature=temperature,
                        top_p=top_p
                        )        
        return chat_completion
    
    async def llm_gateway_chat_completion_streaming(self, client, deployment_name, messages, top_p=0.95, max_tokens=1000, 
                                          temperature=0.0,stream=True, stream_options=True):
        
        chat_completion = client.chat_completions_streaming(
                        deployment_name=deployment_name, 
                        messages=messages,
                        max_tokens=max_tokens, 
                        temperature=temperature,
                        top_p=top_p,
                        stream=True, 
                        # stream_options=True
                        stream_options={"include_usage": True}
                        )     
        # print('CHATTTT : ', chat_completion.json())   
        return chat_completion
    
    
