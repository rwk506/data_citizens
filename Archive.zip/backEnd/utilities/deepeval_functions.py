#********************* Context Relevancy **************************#
# Import Required Libraries
import deepeval
import pytest
import openai
import pandas as pd
import numpy as np
import os
import re
from deepeval.test_case import LLMTestCase
from deepeval.metrics import GEval
from deepeval.test_case import LLMTestCaseParams
from deepeval import evaluate
from deepeval.metrics import ContextualPrecisionMetric
from deepeval.metrics import ContextualRelevancyMetric
from deepeval.metrics import ContextualRecallMetric
from deepeval.metrics import AnswerRelevancyMetric
from deepeval.metrics import FaithfulnessMetric
from deepeval.metrics import BiasMetric
from deepeval.metrics import ToxicityMetric
from deepeval.metrics import HallucinationMetric
from deepeval.metrics.ragas import RagasMetric


def context_relavancy(input,actual_output,context):
    try: 

        metric_relavency = ContextualRelevancyMetric(
            threshold=0.7,
            model="gpt-4-32k",
            include_reason=True
        )
        test_case = LLMTestCase(
            input=input,
            actual_output=actual_output,
            retrieval_context=context
        )

        metric_relavency.measure(test_case)
        answer = round(metric_relavency.score, 2)
    
    except Exception as e:
        answer = None
        
    return (answer)

#******************* Context Recall ***********************#
def context_recall(input,actual_output,expected_output,context):
    try:
        metric_recall = ContextualRecallMetric(
        threshold=0.7,
        model="gpt-4-32k",
        include_reason=True
            )
        test_case_recall = LLMTestCase(
        input=input,
        actual_output=actual_output,
        expected_output=expected_output,
        retrieval_context=context
            )

        metric_recall.measure(test_case_recall)
        answer = round(metric_recall.score, 2)
        
    except Exception as e:
        answer = None
    return(answer)    

#******************* Answer Relevancy ******************#
def answer_relevancy(input,actual_output,context):                
    try:

        metric_answer = AnswerRelevancyMetric(
        threshold=0.7,
        # model="gpt-4",
        model = 'gpt-4-32k',
        include_reason=True
    )
        test_case_answer = LLMTestCase(
            input=input,
            actual_output=actual_output,
            retrieval_context=context
        )

        metric_answer.measure(test_case_answer)
        answer = round(metric_answer.score, 2)
        
    except Exception as e:
        answer = None
        
    return(answer) 

#****************** Faithfulness ***************#
def failthfulness(input,actual_output,context):
    try:
        metric_Faithfullness = FaithfulnessMetric(
        threshold=0.7,
        model="gpt-4-32k",
        include_reason=True
    )
        test_case_Faithfullness = LLMTestCase(
            input=input,
            actual_output=actual_output,
            retrieval_context=context
        )

        metric_Faithfullness.measure(test_case_Faithfullness)
        answer = round(metric_Faithfullness.score, 2)
    except Exception as e:
        answer = None
    return(answer)    

# #****************** Bias Metric *********************#
def bias(input,actual_output):

    try:

        metric_bias = BiasMetric(threshold=0.5)
        test_case_bias = LLMTestCase(
            input=input,
            # Replace this with the actual output from your LLM application
            actual_output=actual_output
        )

        metric_bias.measure(test_case_bias)
        answer = round(metric_bias.score, 2)

    except Exception as e:
        answer = None
        
    return(answer) 

#     #***************** Toxicity **********************#
def toxicity(input,actual_output):
            
    try:
        metric_toxicity = ToxicityMetric(threshold=0.5)
        test_case_toxicity = LLMTestCase(
            input=input,
            # Replace this with the actual output from your LLM application
            actual_output = actual_output
        )

        metric_toxicity.measure(test_case_toxicity)
        answer = round(metric_toxicity.score, 2)
        
    except Exception as e:
        answer = None
        
    return(answer)

