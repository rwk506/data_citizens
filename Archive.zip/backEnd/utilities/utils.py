import os
import time
from azure.storage.blob import BlobServiceClient
import openai
import json
from openai import AzureOpenAI
from .deepeval_functions import context_relavancy, context_recall,answer_relevancy,failthfulness,bias,toxicity
import traceback
from datetime import datetime

def get_sub_files(conn_string, container_name, folder_name):
    blob_folder_name = f'{folder_name}/'
    blob_service_client = BlobServiceClient.from_connection_string(conn_string)
    container_client = blob_service_client.get_container_client(container_name)
    
    # Ensure there is a slash at the end of the folder_name
    if not folder_name.endswith('/'):
        folder_name += '/'
    
    files = []
    for blob in container_client.walk_blobs(blob_folder_name, delimiter='/'):
        blob_relative_path = blob.name[len(folder_name):]
        folder_end = blob_relative_path.find('/')
        if folder_end != -1:
            files.append(blob_relative_path[:folder_end])
    
    return files

def get_files(conn_string, container_name, folder_names):
    """ 
    This function retrieves all the ingested files from the blob storage, a process which is essential during the file indexing stage.
    """
    response = []
    for folder_name in folder_names:
        sub_folder = get_sub_files(conn_string, container_name, folder_name)
        result = {folder_name:sub_folder}
        response.append(result)
    return response

 
def generate_conversation_title(conversation_messages, openai_url, AZURE_OPENAI_KEY, AZURE_OPENAI_MODEL):
        """ 
        This function creates a title for the conversation carried out by the user. 
        """
        title_prompt = 'Summarize the conversation so far into a 4-word or less title. Do not use any quotation marks or punctuation. Respond with a json object in the format {{"title": string}}. Do not include any other commentary or description.'

        messages = [{'role': "user", 'content': msg['user']} for msg in conversation_messages]
        messages.append({'role': 'system', 'content': title_prompt})

        try:
            ## Submit prompt to Chat Completions for response
            client = AzureOpenAI(
            api_key=AZURE_OPENAI_KEY,  
            api_version="2023-03-15-preview",
            azure_endpoint = openai_url
            )
            completion = client.chat.completions.create(
                            model=AZURE_OPENAI_MODEL,
                            messages=messages,
                            max_tokens=100,
                            temperature=0.0)
            
            title = json.loads(completion.choices[0].message.content)['title']
            return title
        except Exception as e:
            return messages[-2]['content']


def get_index_name(index_details, embedding_type, default_index):
    return index_details.get(embedding_type, default_index)

def get_rag_eval_scores(query,llm_answer,retrieval_context_list,show_time_taken = False):
    st = time.time()
    
    #********************* Context Relevancy **************************#
    st_con_rel = time.time()
    context_relavancy_score  = context_relavancy(query,llm_answer,retrieval_context_list)
    

    #******************* Answer Relevancy ******************#
    st_ans_rel = time.time()
    answer_relevancy_score = answer_relevancy(query,llm_answer,retrieval_context_list)
    

    #****************** Faithfulness ***************#
    st_faith = time.time()
    faithfulness_score = failthfulness(query,llm_answer,retrieval_context_list)
    

    composite_score = None
    if (answer_relevancy_score != None) and (context_relavancy_score != None) and (faithfulness_score != None):
        a_r_w=float(os.environ.get('ANSWER_RELEVENCY_WEIGHT', 0.33))
        c_r_w=float(os.environ.get('CONTEXT_RELEVENCY_WEIGHT', 0.33))
        f_r_w=float(os.environ.get('FAITHFULNESS_WEIGHT', 0.34))
        composite_score = round(((a_r_w*float(answer_relevancy_score))+(c_r_w*float(context_relavancy_score))+(f_r_w*float(faithfulness_score))), 2)
                
    output = {
    'composite_score': composite_score,
    'context_relavancy_score':context_relavancy_score,
    'answer_relevancy_score':answer_relevancy_score,
    'failthfulness_score':faithfulness_score
    }
            
    return(output)


def get_config_details(cosmos_config_client):
    """ 
    This function retrieves all the configuration details stored in the environment variables and sends them to the front end for making dynamic content modifications.
    """
    subtitle  = os.environ.get("SUBTITLE")
    try:
        example_question = json.loads(os.environ.get("EXAMPLE_QUESTION"))
    except:
        example_question = []
        
    try:
        get_questions = json.loads(os.environ.get("QUESTIONS"))
    except:
        get_questions = []
        
    try:
        get_advanced_settings = json.loads(os.environ.get("ADVANCED_SETTINGS"))
    except:
        get_advanced_settings = []
    
    try:
        get_source_date_range = json.loads(os.environ.get("SOURCE_DATE_PERIOD"))
    except:
        get_source_date_range = []
    
    model_collection = get_model_collection(get_advanced_settings)
    
    get_retriever_feature = get_retriever_features(get_advanced_settings)
    get_query_transformation_type = get_query_transformation_types(get_advanced_settings)
    
    document_retriever_count= os.environ.get("DOCUMENT_RETRIEVER_COUNT", 8)
    document_retriever_count=int(document_retriever_count)
    return {'title':os.environ.get("APPLICATION_TITLE"),'subtitle':subtitle, 'example_question':example_question, 
            'questions':get_questions, 'advanced_settings':get_advanced_settings, 
            'retriever_feature':get_retriever_feature, 'query_transformation_type':get_query_transformation_type,
            'application_theme_color':os.environ.get("APPLICATION_COLOR_THEME", ''), 'top_ribbon_color':os.environ.get("RIBBON_COLOR", ''), 'application_heading':os.environ.get("APPLICATION_HEADING", ''),
            'model_collection': model_collection, 'document_retriever_count': document_retriever_count, 'source_date_range':get_source_date_range
            }

def get_retriever_features(advanced_settings):
    """ 
    This function is designed to update a retriever feature based on the provided advanced settings.
    """
    try:
        get_retriever_feature = advanced_settings[0].get('retriever_feature')   
        if get_retriever_feature:
            try:
                retriever_features = json.loads(os.environ.get("RETRIEVER_FEATURE"))
            except:
                retriever_features = []
        else:
            retriever_features = []
        return retriever_features
    except:
        retriever_features = []
        return retriever_features
        

def get_query_transformation_types(advanced_settings):
    """ 
    This function is designed to update a query transformation type based on the provided advanced settings.
    """
    try:
        get_query_transformation_type = advanced_settings[0].get('query_transformation_type')   
        if get_query_transformation_type:
            try:
                query_transformation_type = json.loads(os.environ.get("QUERY_TRANSFORMATION_TYPE"))
            except:
                query_transformation_type = []
        else:
            query_transformation_type = []
        return query_transformation_type
    except:
        query_transformation_type = []
        return query_transformation_type

def get_model_collection(advanced_settings):
    """ 
    This function is designed to update a lite llm details based on the provided advanced settings.
    """
    try:
        use_lite_llm = advanced_settings[0].get('use_lite_llm')   
        if use_lite_llm:
            try:
                model_collection = json.loads(os.environ.get("MODEL_COLLECTION"))
            except:
                model_collection = []
        else:
            model_collection = []
        return model_collection
    except:
        model_collection = []
        return model_collection


def summarize_the_conversation(conversation_messages, openai_url, AZURE_OPENAI_KEY, AZURE_OPENAI_MODEL):
    """ 
    This function creates a title for the conversation carried out by the user. 
    """
    # title_prompt = 'Summarize the conversation so far into a 4-word or less title. Do not use any quotation marks or punctuation. Respond with a json object in the format {{"title": string}}. Do not include any other commentary or description.'

    messages = conversation_messages
    try:
        ## Submit prompt to Chat Completions for response
        client = AzureOpenAI(
        api_key=AZURE_OPENAI_KEY,  
        api_version="2023-03-15-preview",
        azure_endpoint = openai_url
        )
        completion = client.chat.completions.create(
                        model=AZURE_OPENAI_MODEL,
                        messages=messages,
                        # max_tokens=1200,
                        temperature=0.7)
        summary = completion.choices[0].message.content
        return summary
    except Exception as e:
        
        print(traceback.format_exc())
        return ''

def date_formatter(date, source_format="%Y-%m-%dT%H:%M:%SZ", to_format="%B %d, %Y"):
    try:
        date_obj = datetime.strptime(date, source_format)
        # 'January 01, 2022'
        formatted_date = date_obj.strftime(to_format)
        return formatted_date
    except Exception as e:
        print(traceback.format_exc())
        return ''