#  
#  

import logging
import mimetypes
import os
import time
import json
import urllib.parse
from datetime import datetime, timedelta
from flask_cors import CORS
import openai
from approaches.chatreadretrieveread import ChatReadRetrieveReadApproach
from azure.core.credentials import AzureKeyCredential
 
from starlette.datastructures import Headers
from flask import Flask, jsonify, request
 
from utilities import utils 
 
from auth.auth_utils import get_authenticated_user_details
from fastapi.staticfiles import StaticFiles
from fastapi import FastAPI, File, HTTPException, Request, UploadFile, Depends, Security
from fastapi.responses import RedirectResponse, StreamingResponse, JSONResponse, FileResponse
import numpy as np
from azure.cosmos import CosmosClient
from fastapi.middleware.cors import CORSMiddleware
import uvicorn
import os
import msal
from fastapi.security import (OAuth2AuthorizationCodeBearer)
import jwt
import requests 
from msal.oauth2cli.oidc import decode_id_token 
from core.apim_llm_gateway import OpenAIAzureAPIMSDK
import traceback
str_to_bool = {'true': True, 'false': False}
# Replace these with your own values, either in environment variables or directly here
 
# OPENAI_DE
# deployment_name, api_version, subscription_key

#loading the embedding weight matrix to be multiplied with query embedding vector
weight_matrix = np.load('best_matrix.npy')

# Use the current user identity to authenticate with Azure OpenAI, Cognitive Search and Blob Storage (no secrets needed,
# just use 'az login' locally, and managed identity when deployed on Azure). If you need to use keys, use separate AzureKeyCredential instances with the
# keys for each service
# If you encounter a blocking error during a DefaultAzureCredntial resolution, you can exclude the problematic credential by using a parameter (ex. exclude_shared_token_cache_credential=True)
# azure_credential = DefaultAzureCredential(exclude_shared_token_cache_credential=True)
 

 

model_name = ''
model_version = ''
 

app = FastAPI(
    title="IA Web API",
    description="A Python API to serve as Backend For the Grant Guru Webapp",
    version="0.1.0",
    docs_url="/docs",
)


app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
) 


static_location = os.path.join(os.getcwd(), "static")
 
 
 # Error handler
class AuthError(Exception):
    def __init__(self, error, status_code):
        self.error = error
        self.status_code = status_code

@app.get("/")
async def root():
    """Serve index.html as root."""
    
    return FileResponse(os.path.join(static_location, "index.html"))

 

@app.get("/assets/{path}")
async def static_file(path):
    """Serve static files from the 'static' directory."""
    assets_location = f"assets/{path}"
    return FileResponse(os.path.join(static_location, assets_location))


def generate_data():
    """ Generator function that simulates data streaming. """
    answer = ""
    for i in range(10):
        #yield f"data: {i}\n\n"
        yield json.dumps({"content": str(i) }) + "\n"
        time.sleep(1)  # simulate data processing delay
        answer = "".join(str(i))

    time.sleep(1)
    
    yield json.dumps({"answer": str(answer), "data_points" : [] }) + "\n"
    

@app.post("/stream")
def stream(): 
    return StreamingResponse(generate_data(), media_type="text/plain")


     

@app.post("/newchat")
async def chat(request: Request):
    """Chat with the bot using a given approach

    Args:
        request (Request): The incoming request object

    Returns:
        dict: The response containing the chat results

    Raises:
        dict: The error response if an exception occurs during the chat
    """
    start_time = time.time()
    json_body = await request.json()

    print("json_body-----", json_body, "++++++++",json_body.get("history", []))
     
    conversation_id = json_body.get("conversation_id")

    try:
        
        rr = ChatReadRetrieveReadApproach()

        r = rr.generate(json_body.get("history", []), json_body.get("overrides", {}), conversation_id, start_time, "")
       
        return StreamingResponse(r, media_type="application/x-ndjson")

    except Exception as ex:
       logging.error(f"Error /chat:: {str(traceback.format_exc())}")
       raise HTTPException(status_code=500, detail=str(ex)) from ex
    
   

if __name__ == "__main__":
    logging.info("IA WebApp Starting Up...")
    # app.run(threaded=True, debug=False)
    uvicorn.run('app:app', host='0.0.0.0', port=8000)
