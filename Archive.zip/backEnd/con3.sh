#AWS Details
export AWS_ACCESS_KEY_ID="AKIAR5ESAXRDHUTJAJW4"
export AWS_SECRET_ACCESS_KEY="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"
export AWS_DEFAULT_REGION="us-east-1"
export S3_BUCKET_NAME="kpmg-meta-hackathon"
export S3_FILE_KEY="Hackathon_Data.xlsx"
export DYNAMODB_TABLE_NAME="meta-chunks"
export BEDROCK_MODEL_ID="llama-3-8b"
export IAM_ROLE_ARN="arn:aws:iam::131302734918:user/meta-hackathon"
export QDRANT_URL="https://42800922-23b6-4089-a5ab-6f92c30081e3.us-east4-0.gcp.cloud.qdrant.io:6333"
export QDRANT_API_KEY="xfqv1pUX-i03MY9hz4CHjTXtVT2_ImfolTJ4HDm9Fz_IM6pSFG8i9A"
export COLLECTION_NAME="example_data3"
export OPENSEARCH_URL="https://search-meta-opensearch-2twcef2x72knmrytelbcdafjm4.us-east-1.es.amazonaws.com"
export SYSTEM_CONTEXT="You are a helpful assistant and professional that works with non profit organizations. You look for relevant grants that they are eligible for. Be transparent - if you don't know the answer or it isn't clear, do not guess and say it is not clear. Cite relevant reference text whenever possible"
export GROC_API="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"

 